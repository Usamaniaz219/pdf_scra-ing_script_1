import nltk
nltk.download('punkt') 
from nltk.tokenize import sent_tokenize
import string
import re 

matches = []
def repl_original(m):
	mm = m.group()
	matches.append(mm)
	mm = "\n".join(mm.split(" ", 1))
	return mm

def repl_two(m):
        matches.append(m.group())
        return "{}\n".format(m.group())

def repl(m):
        mm = m.group()
        mm = mm.replace("\n","")
        # print(mm)
        matches.append(mm)
        return "\n{} ".format(mm)

def insert_line_break(m):
        mm = m.group()
        mm = mm.replace("\n","")
        # print(mm)
        matches.append(mm)
        return "\n{} ".format(mm)

def insert_line_break_two(m):
        mm = m.group()
        mm = mm.split(" ", 1)
        # print(mm)
        matches.append(mm)
        return f"{mm[0]}\n{mm[-1]}"

def insert_line_break_colon(m):
        mm = m.group()
        mm = mm.replace(": ",":\n")
        # print(mm)
        matches.append(mm)
        return "{}".format(mm)

def remove_line_break(m):
        mm = m.group()
        mm = mm.replace("\n","")
        # print(mm)
        matches.append(mm)
        return "{} ".format(mm)


def remove_line_break_two(m):
        mm = m.group()
        mm = mm.replace("\n"," ")
        # print(mm)
        matches.append(mm)
        return "{}".format(mm)

def break_numerical_headings(m):
    mm = m.group()
    mm = mm.replace("\n", "")
    # print(mm)
    matches.append(mm)
    return "\n{} ".format(mm)

def join_zone_keywords(m):
    mm = m.group()
    mm = mm.replace("\n", " ")
    # print(mm)
    matches.append(mm)
    return "\n{}".format(mm)

def break_zone_keywords(m):
    mm = m.group()
    mm = mm.replace(" ", "\n")
    # print(mm)
    matches.append(mm)
    return format(mm)

def ecode_title_processing(title):
    title = title.replace("—", "-")
    title = title.replace("\n", " ")
    return title

def ecode_textProcessing(all_text, output_type = None):

	# merge all sentences
	all_text = all_text.replace("\n", " ")
	#
	all_text = all_text.replace("See §", "")
	# remove [Ord. ...]
	if output_type != "csv":
		all_text = re.sub('\[Ord.*?\]', '', all_text)
		# remove [Added ...]
		all_text = re.sub('\[Added?.*?\]', '', all_text)
		# remove [Amended ...]
		all_text = re.sub('\[Amended?.*?\]', '', all_text)
		# remove Editor's Note
                
		all_text = re.sub("\[.\] Editor's Note:", '', all_text)
		# remove [.] Editor's Note: See ...
		all_text = re.sub("\[.\] Editor's Note: See?.*\.", '', all_text)
    
	# replace double spaces with a single space
	all_text = re.sub(' +', ' ', all_text)
	# tokenize into sentences
	all_text = sent_tokenize(all_text)
	# merge all tokeized sentences
	all_text = '\n'.join(all_text)
	all_text = all_text.replace(" § ", "\n§ ")
	all_text = all_text.replace(" §", "\n§ ")

	# Break sentences at appropriate uppercased and lowercased bullets
	all_upper_alphabets = list(string.ascii_uppercase)
	all_lower_alphabets = list(string.ascii_lowercase)

	for iteration, item in enumerate(all_lower_alphabets):
		sub_string_pattern = "\n" + item + "." + "\n"
		rep_string_pattern = "\n" + item + "." + " "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = ": " + item + "." + "\n"
		rep_string_pattern = ":\n" + item + "." + " "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = ": " + item + "." + " "
		rep_string_pattern = ":\n" + item + "." + " "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = " " + item + "." + "\n"
		rep_string_pattern = "\n" + item + "." + " "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = ": (" + item + ")"
		rep_string_pattern = ":\n(" + item + ")"
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = ". " + item + ". "
		rep_string_pattern = ".\n" + item + ". "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + "\n"
		rep_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + " "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = ": " + all_upper_alphabets[iteration] + "." + "\n"
		rep_string_pattern = ":\n" + all_upper_alphabets[iteration] + "." + " "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = ": " + all_upper_alphabets[iteration] + "." + " "
		rep_string_pattern = ":\n" + all_upper_alphabets[iteration] + "." + " "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = " " + all_upper_alphabets[iteration] + "." + "\n"
		rep_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + " "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = ": (" + all_upper_alphabets[iteration] + ")"
		rep_string_pattern = ":\n(" + all_upper_alphabets[iteration] + ")"
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	# Break sentence at bullet where the last character of the previous sentence is a digit
	pattern = re.compile(r'\d [a-z, A-Z]\. ')
	all_text = re.sub(pattern, repl_original, all_text)

	# Break sentence at appropriate numbered bullets
	for num in range(1, 150):

		sub_string_pattern = ": (" + str(num) + ")"
		rep_string_pattern = ":\n(" + str(num) + ")"
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = "\n" + str(num) + "." + "\n"
		rep_string_pattern = "\n" + str(num) + "." + " "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = " (" + str(num) + ") "
		rep_string_pattern = "\n(" + str(num) + ") "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

		sub_string_pattern = " " + str(num) + ".\n"
		rep_string_pattern = "\n" + str(num) + ". "
		all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	##-----------------------------------------------------------------##
	# remove wrong breaks occured during bullet corrections
	# pattern = re.compile(r' chapter\n')
	# all_text = re.sub(pattern, repl, all_text) 

	##-----------------------------------------------------------------##
	# Insert line breaks

	# insert line break for numerical bullet point of arbitrary length
	# pattern = re.compile(r' [\d\-\. ]{4,15} | [\d\-\. ]{4,15}\n')
	pattern = re.compile(r'[^,] [\d\-\.\:]{4,15} |[^,] [\d\-\.\:]{4,15}\n')
	all_text = re.sub(pattern, insert_line_break_two, all_text)

	# insert line breaks for numerical bullets with length less than 4
	pattern = re.compile(r' \d[\.\-\:]{1,1}\d[\.\-\:]{0,1} ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	pattern = re.compile(r'[ \n]\d[\w\-\.]{4,15}:')
	all_text = re.sub(pattern, insert_line_break, all_text)

	pattern = re.compile(r'[a-zA-Z]: [A-Z]')
	all_text = re.sub(pattern, insert_line_break_colon, all_text)

	sub_string_pattern = "Sections: "
	rep_string_pattern = "Sections:\n"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = " Footnotes:"
	rep_string_pattern = "\nFootnotes:"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = " Secs."
	rep_string_pattern = "\nSecs."
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = " )"
	rep_string_pattern = ")"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "\nFeet "
	rep_string_pattern = "\nFeet\n"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	pattern = re.compile(r' Sec.[ \n]')
	all_text = re.sub(pattern, repl, all_text)

	##-----------------------------------------------------------------##
	# break sentences at keyword "Chapter" or "CHAPTER" or "Chap." or "CHAP."
	pattern = re.compile(r' Chapter | CHAPTER | Chap\. | CHAP\. ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	# break sentences at keyword "Article" or "ARTICLE" or "Art." or "ART."
	pattern = re.compile(r' Article | ARTICLE | Art\. | ART\. ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	# break sentences at keyword "Division" or "DIVISION" or "Div." or "DIV."
	pattern = re.compile(r' Division | DIVISION ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	pattern = re.compile(r' Div\. | DIV\. ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	# break sentences at keyword "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
	pattern = re.compile(r' Subdivision | SUBDIVISION | SUB-DIVISION | Sub-Division ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	# break sentences at keyword "Part" or "PART"
	pattern = re.compile(r' Part | PART ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	# break sentences at keyword "Section" or "SECTION" or "SEC." or "Sec."
	pattern = re.compile(r' Section | SECTION ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	pattern = re.compile(r' SEC\. | Sec\. | Secs\.')
	all_text = re.sub(pattern, insert_line_break, all_text)
	##-----------------------------------------------------------------##
	pattern = re.compile(r'[ \-]{0,1}\d\d\d\d\) ')
	all_text = re.sub(pattern, repl_two, all_text)

	pattern = re.compile(r'\w\. \w\. ')
	all_text = re.sub(pattern, insert_line_break_two, all_text)
	##-----------------------------------------------------------------##

	all_text = re.sub('\n+', '\n', all_text)

	sub_string_pattern = "\n "
	rep_string_pattern = "\n"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	all_text = all_text.split('\n')
	for iteration, text in enumerate(all_text):
		text = text.strip()
		all_text[iteration] = text
	all_text = '\n'.join(all_text)


	# Remove line breaks

	# remove line break for numerical bullet point of arbitrary length
	pattern = re.compile(r'[\d\-\.]{2,15}\n[a-zA-Z\-]{2,2}')
	all_text = re.sub(pattern, remove_line_break_two, all_text)

	pattern = re.compile(r'Division\n|DIVISION\n')
	all_text = re.sub(pattern, repl, all_text)

	sub_string_pattern = "Sec.\n"
	rep_string_pattern = "Sec. "
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	##-----------------------------------------------------------------##
	# remove sentence breaks occurring immediately after keywords "Chapter" or "CHAPTER" or "Chap." or "CHAP."
	pattern = re.compile(r'\nChapter\n| Chapter\n|Chapter\n|\nCHAPTER\n| CHAPTER\n|CHAPTER\n')
	all_text = re.sub(pattern, repl, all_text)

	pattern = re.compile(r'\nChap\.\n| Chap\.\n|Chap\.\n|\nCHAP\.\n| CHAP\.\n|CHAP\.\n')
	all_text = re.sub(pattern, repl, all_text)

	# remove sentence breaks occurring immediately after keywords "Article" or "ARTICLE" or "Art." or "ART."
	pattern = re.compile(r'\nArticle\n| Article\n|Article\n|\nARTICLE\n| ARTICLE\n|ARTICLE\n')
	all_text = re.sub(pattern, repl, all_text)

	pattern = re.compile(r'\nArt\.\n| Art\.\n|Art\.\n|\nART\.\n| ART\.\n|ART\.\n')
	all_text = re.sub(pattern, repl, all_text)

	# remove sentence breaks occurring immediately after keywords "Division" or "DIVISION" or "Div." or "DIV."
	pattern = re.compile(r'\nDivision\n| Division\n|Division\n|\nDIVISION\n| DIVISION\n|DIVISION\n')
	all_text = re.sub(pattern, repl, all_text)

	pattern = re.compile(r'\nDiv\.\n| Div\.\n|Div\.\n|\nDIV\.\n| DIV.\n|DIV\.\n')
	all_text = re.sub(pattern, repl, all_text)

	# remove sentence breaks occurring immediately after keywords "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
	pattern = re.compile(r'\nSubdivision\n| Subdivision\n|Subdivision\n|\nSUBDIVISION\n| SUBDIVISION\n|SUBDIVISION\n')
	all_text = re.sub(pattern, insert_line_break, all_text)

	pattern = re.compile(r'\nSub-Division\n| Sub-Division\n|Sub-Division\n|\nSUB-DIVISION\n| SUB-DIVISION\n|SUB-DIVISION\n')
	all_text = re.sub(pattern, insert_line_break, all_text)

	# remove sentence breaks occurring immediately after keywords "Part" or "PART"
	pattern = re.compile(r'\nPart\n| Part\n|Part\n|\nPART\n| PART\n|PART\n')
	all_text = re.sub(pattern, repl, all_text)

	# remove sentence breaks occurring immediately after keywords "Section" or "SECTION" or "SEC." or "Sec." or "Secs."
	pattern = re.compile(r'\nSection\n| Section\n|Section\n|\nSECTION\n| SECTION\n|SECTION\n| Sections\n')
	all_text = re.sub(pattern, repl, all_text)

	pattern = re.compile(r'\nSec\.\n| Sec\.\n|Sec\.\n|\nSecs\.\n| Secs\.\n|Secs\.\n|\nSEC\.\n| SEC\.\n|SEC\.\n')
	all_text = re.sub(pattern, repl, all_text)
	##-----------------------------------------------------------------##

	# remove sentence breaks occurring immediately after keywords "Article I./1." or "ARTICLE I./1."
	pattern = re.compile(r'\nArticle [\w\.\-]{1,25}\n')
	all_text = re.sub(pattern, repl, all_text)
	##-----------------------------------------------------------------##


	pattern = re.compile(r'[\.\:]\n\-')
	all_text = re.sub(pattern, remove_line_break, all_text)

	# break sentence at Table 5.
	pattern = re.compile(r'Table[ \n]\w\.')
	all_text = re.sub(pattern, repl_two, all_text)

	##-----------------------------------------------------------------##

	##-----------------------------------------------------------------##

	# Break at "reserved"
	sub_string_pattern = "(Reserved) "
	rep_string_pattern = "(Reserved)\n"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "Reserved "
	rep_string_pattern = "Reserved\n"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "\nFeet"
	rep_string_pattern = " Feet"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
	##-----------------------------------------------------------------##


	# Remove strings

	sub_string_pattern = "Sections:"
	rep_string_pattern = ""
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "modified\n"
	rep_string_pattern = "\n"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	##-----------------------------------------------------------------##
	all_text = re.sub('\n+', '\n', all_text)

	sub_string_pattern = "\n "
	rep_string_pattern = "\n"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
	##-----------------------------------------------------------------##

	# Insert line breaks 2 (again)

	# Break line at YEAR (problematic in few cases)
	# pattern = re.compile(r'\d\d\d\d[\)\.]{1,1} ')
	# all_text = re.sub(pattern, repl_two, all_text) 


	# break sentences at keyword "Chapter" or "CHAPTER" or "Chap." or "CHAP."
	pattern = re.compile(r' Chapter | CHAPTER | Chap\. | CHAP\. ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	# break sentences at keyword "Article" or "ARTICLE" or "Art." or "ART."
	pattern = re.compile(r' Article | ARTICLE | Art\. | ART\. ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	# break sentences at keyword "Division" or "DIVISION" or "Div." or "DIV."
	pattern = re.compile(r' Division | DIVISION ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	# break sentences at keyword "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
	pattern = re.compile(r' Subdivision | SUBDIVISION | SUB-DIVISION | Sub-Division ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	pattern = re.compile(r' Div\. | DIV\. ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	# break sentences at keyword "Part" or "PART"
	pattern = re.compile(r' Part | PART ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	# break sentences at keyword "Section" or "SECTION" or "SEC." or "Sec."
	pattern = re.compile(r' Section | SECTION ')
	all_text = re.sub(pattern, insert_line_break, all_text)

	pattern = re.compile(r' SEC\. | Sec\. | Secs\.')
	all_text = re.sub(pattern, insert_line_break, all_text)
	##-----------------------------------------------------------------##

	##-----------------------------------------------------------------##
	# Remove extra line breaks

	all_text = re.sub('\n+', '\n', all_text)

	sub_string_pattern = "\n "
	rep_string_pattern = "\n"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	# # remove sentence breaks occurring immediately after "in" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
	# pattern = re.compile(r'in\nSection|in\nSECTION|in\nSec\.|in\nSecs\.|in\nSEC\.')
	# all_text = re.sub(pattern, remove_line_break_two, all_text)

	# # remove sentence breaks occurring immediately after "by" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
	# pattern = re.compile(r'by\nSection|by\nSECTION|by\nSec\.|by\nSecs\.|by\nSEC\.')
	# all_text = re.sub(pattern, remove_line_break_two, all_text)

	# # remove sentence breaks occurring immediately after "or" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
	# pattern = re.compile(r'or\nSection|or\nSECTION|or\nSec\.|or\nSecs\.|or\nSEC\.')
	# all_text = re.sub(pattern, remove_line_break_two, all_text)

	# # remove sentence breaks occurring immediately after "and" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
	# pattern = re.compile(r'and\nSection|and\nSECTION|and\nSec\.|and\nSecs\.|and\nSEC\.')
	# all_text = re.sub(pattern, remove_line_break_two, all_text)
	# ##-----------------------------------------------------------------##

	# # remove sentence breaks occurring immediately after "in" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
	# pattern = re.compile(r'in\nArticle|in\nARTICLE|in\nArt\.|in\nART\.')
	# all_text = re.sub(pattern, remove_line_break_two, all_text)

	# # remove sentence breaks occurring immediately after "by" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
	# pattern = re.compile(r'by\nArticle|by\nARTICLE|by\nArt\.|by\nART\.')
	# all_text = re.sub(pattern, remove_line_break_two, all_text)

	# # remove sentence breaks occurring immediately after "or" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
	# pattern = re.compile(r'or\nArticle|or\nARTICLE|or\nArt\.|or\nART\.')
	# all_text = re.sub(pattern, remove_line_break_two, all_text)

	# # remove sentence breaks occurring immediately after "and" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
	# pattern = re.compile(r'and\nArticle|and\nARTICLE|and\nArt\.|and\nART\.')
	# all_text = re.sub(pattern, remove_line_break_two, all_text)
	##-----------------------------------------------------------------##

	# Break sentences at "§"
	sub_string_pattern = "%" + " " + "§"
	rep_string_pattern = "%" + "\n" + "§"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "feet" + " " + "§"
	rep_string_pattern = "feet" + "\n" + "§"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "." + " " + "§"
	rep_string_pattern = "." + "\n" + "§"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "}" + " "
	rep_string_pattern = "}" + "\n"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = " (subject to "
	rep_string_pattern = "\n(subject to "
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	# Remove breaks from wrong places caused by §
	sub_string_pattern = "in\n§"
	rep_string_pattern = "in §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = ",\n§"
	rep_string_pattern = ", §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = ";\n§"
	rep_string_pattern = "; §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "to\n§"
	rep_string_pattern = "to §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "and\n§"
	rep_string_pattern = "and §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "with\n§"
	rep_string_pattern = "with §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "per\n§"
	rep_string_pattern = "per §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "of\n§"
	rep_string_pattern = "of §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "through\n§"
	rep_string_pattern = "through §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "by\n§"
	rep_string_pattern = "by §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "under\n§"
	rep_string_pattern = "under §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "standing\n§"
	rep_string_pattern = "standing §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "See\n§"
	rep_string_pattern = "See §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "see\n§"
	rep_string_pattern = "see §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "for\n§"
	rep_string_pattern = "for §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "as\n§"
	rep_string_pattern = "as §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "at\n§"
	rep_string_pattern = "at §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "excluding\n§"
	rep_string_pattern = "excluding §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "ode\n§"
	rep_string_pattern = "ode §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "also\n§"
	rep_string_pattern = "also §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "this\n§"
	rep_string_pattern = "this §"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	# Break at "reserved"
	sub_string_pattern = "(Reserved) "
	rep_string_pattern = "(Reserved)\n"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "Reserved "
	rep_string_pattern = "Reserved\n"
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	# Break at brackets
	sub_string_pattern = "] ("
	rep_string_pattern = "]\n("
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = ") ["
	rep_string_pattern = ")\n["
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	pattern = re.compile(r'§\n[ ]{0,1}\d')
	all_text = re.sub(pattern, remove_line_break_two, all_text)
        ##-----------------------------------------------------------------##
	sub_string_pattern = "article\n"
	rep_string_pattern = "article "
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

	sub_string_pattern = "section\n"
	rep_string_pattern = "section "
	all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
        ##-----------------------------------------------------------------##
        
        # replace double spaces with a single space
	all_text = re.sub(' +', ' ', all_text)

	all_text = re.sub('\n+', '\n', all_text)
	all_text = all_text.split('\n')
	for iteration, text in enumerate(all_text):
		text = text.strip()
		all_text[iteration] = text
	all_text = '\n'.join(all_text)
	
	return all_text



def municode_textProcessing(all_text):

        # merge all sentences
        all_text = all_text.replace("\n", " ")
        # Correct full stops
        all_text = all_text.replace(" . ", ". ")
        #
        #all_text = all_text.replace("See §", "")
        # remove (Ord. ...)
        # all_text = re.sub('\(Ord.*?\)\D.*?\)', '', all_text)
        # all_text = re.sub('\(\sOrd\. No\..*?\)', '', all_text)
        # all_text = re.sub('\(Ord.*?\)', '', all_text)
        # # remove [Added ...]
        # all_text = re.sub('\(Code.*?\)', '', all_text)
        # # remove [Amended ...]
        # all_text = re.sub('\(P\.A\..*?\)', '', all_text)
        # # remove Editor's Note
        # all_text = re.sub("\[.\] Editor's Note:", '', all_text)
        # # remove [.] Editor's Note: See ...
        # all_text = re.sub("\[.\] Editor's Note: See?.*\.", '', all_text)
        # replace [Sec.] with Sec.
        all_text = re.sub("\[Sec.\]", 'Sec.', all_text)
        # replace [Sec. with Sec.
        all_text = re.sub("\[Sec.", 'Sec.', all_text)
        # replace double spaces with a single space
        all_text = re.sub(' +', ' ', all_text)
        # Break after year and paranthesis, e.g. 1996)
        # all_text = re.sub('\d\d\d\d\)\s\d', '\n', all_text)
        # tokenize into sentences
        all_text = sent_tokenize(all_text)
        for iteration, text in enumerate(all_text):
                text = text.strip()
                all_text[iteration] = text
        # merge all tokeized sentences
        all_text = '\n'.join(all_text)
        all_text = all_text.replace(" § ", "\n§ ")
        all_text = all_text.replace(" §", "\n§")


        # Break sentences at appropriate uppercased and lowercased bullets
        roman_numerals = ["ii", "iii", "iv", "vi", "vii", "viii", "ix"]

        for roman_numeral in roman_numerals:
                sub_string_pattern = "\n" + roman_numeral + "." + "\n"
                rep_string_pattern = "\n" + roman_numeral + "." + " "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; (" + roman_numeral + ") "
                rep_string_pattern = ";\n(" + roman_numeral + ") "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; " + roman_numeral + ".\n"
                rep_string_pattern = ";\n" + roman_numeral + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; and " + roman_numeral + ".\n"
                rep_string_pattern = "; and\n" + roman_numeral + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        all_upper_alphabets = list(string.ascii_uppercase)
        all_lower_alphabets = list(string.ascii_lowercase)

        for iteration, item in enumerate(all_lower_alphabets):
                sub_string_pattern = "\n" + item + "." + "\n"
                rep_string_pattern = "\n" + item + "." + " "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = ": " + item + "." + "\n"
                rep_string_pattern = ":\n" + item + "." + " "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = ": " + item + "." + " "
                rep_string_pattern = ":\n" + item + "." + " "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = " " + item + "." + "\n"
                rep_string_pattern = "\n" + item + "." + " "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = ": (" + item + ")"
                rep_string_pattern = ":\n(" + item + ")"
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; " + item + ")"
                rep_string_pattern = ";\n" + item + ")"
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; " + item + ". "
                rep_string_pattern = ";\n" + item + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; and " + item + ". "
                rep_string_pattern = "; and\n" + item + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; " + item + item + ". "
                rep_string_pattern = ";\n" + item + item +". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; " + item + item + ".\n"
                rep_string_pattern = ";\n" + item + item + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "\n" + item + item + ".\n"
                rep_string_pattern = "\n" + item + item + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; (" + item + ")"
                rep_string_pattern = ";\n(" + item + ")"
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + "\n"
                rep_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + " "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = ": " + all_upper_alphabets[iteration] + "." + "\n"
                rep_string_pattern = ":\n" + all_upper_alphabets[iteration] + "." + " "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = ": " + all_upper_alphabets[iteration] + "." + " "
                rep_string_pattern = ":\n" + all_upper_alphabets[iteration] + "." + " "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = " " + all_upper_alphabets[iteration] + "." + "\n"
                rep_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + " "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = ": (" + all_upper_alphabets[iteration] + ")"
                rep_string_pattern = ":\n(" + all_upper_alphabets[iteration] + ")"
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; " + all_upper_alphabets[iteration] + ")"
                rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + ")"
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; " + all_upper_alphabets[iteration] + ". "
                rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; and " + all_upper_alphabets[iteration] + ". "
                rep_string_pattern = "; and\n" + all_upper_alphabets[iteration] + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; " + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
                rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; " + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ".\n"
                rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ".\n"
                rep_string_pattern = "\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; (" + all_upper_alphabets[iteration] + ")"
                rep_string_pattern = ";\n(" + all_upper_alphabets[iteration] + ")"
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        # Break sentence at appropriate numbered bullets
        for num in range(1, 100):

                sub_string_pattern = ": (" + str(num) + ")"
                rep_string_pattern = ":\n(" + str(num) + ")"
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "\n" + str(num) + "." + "\n"
                rep_string_pattern = "\n" + str(num) + "." + " "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = " (" + str(num) + ") "
                rep_string_pattern = "\n(" + str(num) + ") "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = " " + str(num) + ".\n"
                rep_string_pattern = "\n" + str(num) + ". "
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

                sub_string_pattern = "; " + str(num) + ")"
                rep_string_pattern = ";\n" + str(num) + ")"
                all_text = all_text.replace(sub_string_pattern, rep_string_pattern)


        ##-----------------------------------------------------------------##
        # remove wrong breaks occured during bullet corrections
        # pattern = re.compile(r' chapter\n')
        # all_text = re.sub(pattern, repl, all_text) 

        ##-----------------------------------------------------------------##
        # Insert line breaks

        # insert line break for numerical bullet point of arbitrary length
        # pattern = re.compile(r' [\d\-\. ]{4,15} | [\d\-\. ]{4,15}\n')
        pattern = re.compile(r'[^,] [\d\-\.\:]{4,15} |[^,] [\d\-\.\:]{4,15}\n')
        all_text = re.sub(pattern, insert_line_break_two, all_text)

        # insert line breaks for numerical bullets with length less than 4
        pattern = re.compile(r' \d[\.\-\:]{1,1}\d[\.\-\:]{0,1} ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        pattern = re.compile(r'[ \n]\d[\w\-\.]{4,15}:')
        all_text = re.sub(pattern, insert_line_break, all_text)

        pattern = re.compile(r'[a-zA-Z]: [A-Z]')
        all_text = re.sub(pattern, insert_line_break_colon, all_text)

        sub_string_pattern = "Sections: "
        rep_string_pattern = "Sections:\n"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = " Footnotes:"
        rep_string_pattern = "\nFootnotes:"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = " Secs."
        rep_string_pattern = "\nSecs."
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = " )"
        rep_string_pattern = ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "\nFeet "
        rep_string_pattern = "\nFeet\n"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        pattern = re.compile(r' Sec.[ \n]')
        all_text = re.sub(pattern, repl, all_text)

        ##-----------------------------------------------------------------##
        # break sentences at keyword "Chapter" or "CHAPTER" or "Chap." or "CHAP."
        pattern = re.compile(r' Chapter | CHAPTER | Chap\. | CHAP\. ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        # break sentences at keyword "Article" or "ARTICLE" or "Art." or "ART."
        pattern = re.compile(r' Article | ARTICLE | Art\. | ART\. ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        # break sentences at keyword "Division" or "DIVISION" or "Div." or "DIV."
        pattern = re.compile(r' Division | DIVISION ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        pattern = re.compile(r' Div\. | DIV\. ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        # break sentences at keyword "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
        pattern = re.compile(r' Subdivision | SUBDIVISION | SUB-DIVISION | Sub-Division ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        # break sentences at keyword "Part" or "PART"
        pattern = re.compile(r' Part | PART ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        # break sentences at keyword "Section" or "SECTION" or "SEC." or "Sec."
        pattern = re.compile(r' Section | SECTION ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        pattern = re.compile(r' SEC\. | Sec\. | Secs\.')
        all_text = re.sub(pattern, insert_line_break, all_text)
        ##-----------------------------------------------------------------##
        pattern = re.compile(r'[ \-]{0,1}\d\d\d\d\) ')
        all_text = re.sub(pattern, repl_two, all_text)

        pattern = re.compile(r'\w\. \w\. ')
        all_text = re.sub(pattern, insert_line_break_two, all_text)
        ##-----------------------------------------------------------------##

        all_text = re.sub('\n+', '\n', all_text)

        sub_string_pattern = "\n "
        rep_string_pattern = "\n"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        all_text = all_text.split('\n')
        for iteration, text in enumerate(all_text):
                text = text.strip()
                all_text[iteration] = text
        all_text = '\n'.join(all_text)


        # Remove line breaks

        # remove line break for numerical bullet point of arbitrary length
        pattern = re.compile(r'[\d\-\.]{2,15}\n[a-zA-Z\-]{2,2}')
        all_text = re.sub(pattern, remove_line_break_two, all_text)

        pattern = re.compile(r'Division\n|DIVISION\n')
        all_text = re.sub(pattern, repl, all_text)

        sub_string_pattern = "Sec.\n"
        rep_string_pattern = "Sec. "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        ##-----------------------------------------------------------------##
        # remove sentence breaks occurring immediately after keywords "Chapter" or "CHAPTER" or "Chap." or "CHAP."
        pattern = re.compile(r'\nChapter\n| Chapter\n|Chapter\n|\nCHAPTER\n| CHAPTER\n|CHAPTER\n')
        all_text = re.sub(pattern, repl, all_text)

        pattern = re.compile(r'\nChap\.\n| Chap\.\n|Chap\.\n|\nCHAP\.\n| CHAP\.\n|CHAP\.\n')
        all_text = re.sub(pattern, repl, all_text)

        # remove sentence breaks occurring immediately after keywords "Article" or "ARTICLE" or "Art." or "ART."
        pattern = re.compile(r'\nArticle\n| Article\n|Article\n|\nARTICLE\n| ARTICLE\n|ARTICLE\n')
        all_text = re.sub(pattern, repl, all_text)

        pattern = re.compile(r'\nArt\.\n| Art\.\n|Art\.\n|\nART\.\n| ART\.\n|ART\.\n')
        all_text = re.sub(pattern, repl, all_text)

        # remove sentence breaks occurring immediately after keywords "Division" or "DIVISION" or "Div." or "DIV."
        pattern = re.compile(r'\nDivision\n| Division\n|Division\n|\nDIVISION\n| DIVISION\n|DIVISION\n')
        all_text = re.sub(pattern, repl, all_text)

        pattern = re.compile(r'\nDiv\.\n| Div\.\n|Div\.\n|\nDIV\.\n| DIV.\n|DIV\.\n')
        all_text = re.sub(pattern, repl, all_text)

        # remove sentence breaks occurring immediately after keywords "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
        pattern = re.compile(r'\nSubdivision\n| Subdivision\n|Subdivision\n|\nSUBDIVISION\n| SUBDIVISION\n|SUBDIVISION\n')
        all_text = re.sub(pattern, insert_line_break, all_text)

        pattern = re.compile(r'\nSub-Division\n| Sub-Division\n|Sub-Division\n|\nSUB-DIVISION\n| SUB-DIVISION\n|SUB-DIVISION\n')
        all_text = re.sub(pattern, insert_line_break, all_text)

        # remove sentence breaks occurring immediately after keywords "Part" or "PART"
        pattern = re.compile(r'\nPart\n| Part\n|Part\n|\nPART\n| PART\n|PART\n')
        all_text = re.sub(pattern, repl, all_text)

        # remove sentence breaks occurring immediately after keywords "Section" or "SECTION" or "SEC." or "Sec." or "Secs."
        pattern = re.compile(r'\nSection\n| Section\n|Section\n|\nSECTION\n| SECTION\n|SECTION\n| Sections\n')
        all_text = re.sub(pattern, repl, all_text)

        pattern = re.compile(r'\nSec\.\n| Sec\.\n|Sec\.\n|\nSecs\.\n| Secs\.\n|Secs\.\n|\nSEC\.\n| SEC\.\n|SEC\.\n')
        all_text = re.sub(pattern, repl, all_text)
        ##-----------------------------------------------------------------##

        # remove sentence breaks occurring immediately after keywords "Article I./1." or "ARTICLE I./1."
        pattern = re.compile(r'\nArticle [\w\.\-]{1,25}\n')
        all_text = re.sub(pattern, repl, all_text)
        ##-----------------------------------------------------------------##


        pattern = re.compile(r'[\.\:]\n\-')
        all_text = re.sub(pattern, remove_line_break, all_text)

        # break sentence at Table 5.
        pattern = re.compile(r'Table[ \n]\w\.')
        all_text = re.sub(pattern, repl_two, all_text)

        ##-----------------------------------------------------------------##

        ##-----------------------------------------------------------------##

        # Break at "reserved"
        sub_string_pattern = "(Reserved) "
        rep_string_pattern = "(Reserved)\n"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "Reserved "
        rep_string_pattern = "Reserved\n"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "\nFeet"
        rep_string_pattern = " Feet"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
        ##-----------------------------------------------------------------##


        # Remove strings

        sub_string_pattern = "Sections:"
        rep_string_pattern = ""
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "modified\n"
        rep_string_pattern = "\n"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        ##-----------------------------------------------------------------##
        all_text = re.sub('\n+', '\n', all_text)

        sub_string_pattern = "\n "
        rep_string_pattern = "\n"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
        ##-----------------------------------------------------------------##

        # Insert line breaks 2 (again)

        # Break line at YEAR (problematic in few cases)
        # pattern = re.compile(r'\d\d\d\d[\)\.]{1,1} ')
        # all_text = re.sub(pattern, repl_two, all_text) 


        # break sentences at keyword "Chapter" or "CHAPTER" or "Chap." or "CHAP."
        pattern = re.compile(r' Chapter | CHAPTER | Chap\. | CHAP\. ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        # break sentences at keyword "Article" or "ARTICLE" or "Art." or "ART."
        pattern = re.compile(r' Article | ARTICLE | Art\. | ART\. ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        # break sentences at keyword "Division" or "DIVISION" or "Div." or "DIV."
        pattern = re.compile(r' Division | DIVISION ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        # break sentences at keyword "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
        pattern = re.compile(r' Subdivision | SUBDIVISION | SUB-DIVISION | Sub-Division ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        pattern = re.compile(r' Div\. | DIV\. ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        # break sentences at keyword "Part" or "PART"
        pattern = re.compile(r' Part | PART ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        # break sentences at keyword "Section" or "SECTION" or "SEC." or "Sec."
        pattern = re.compile(r' Section | SECTION ')
        all_text = re.sub(pattern, insert_line_break, all_text)

        pattern = re.compile(r' SEC\. | Sec\. | Secs\.')
        all_text = re.sub(pattern, insert_line_break, all_text)
        ##-----------------------------------------------------------------##

        ##-----------------------------------------------------------------##
        # Remove extra line breaks

        all_text = re.sub('\n+', '\n', all_text)

        sub_string_pattern = "\n "
        rep_string_pattern = "\n"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        # # remove sentence breaks occurring immediately after "in" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
        # pattern = re.compile(r'in\nSection|in\nSECTION|in\nSec\.|in\nSecs\.|in\nSEC\.')
        # all_text = re.sub(pattern, remove_line_break_two, all_text)

        # # remove sentence breaks occurring immediately after "by" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
        # pattern = re.compile(r'by\nSection|by\nSECTION|by\nSec\.|by\nSecs\.|by\nSEC\.')
        # all_text = re.sub(pattern, remove_line_break_two, all_text)

        # # remove sentence breaks occurring immediately after "or" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
        # pattern = re.compile(r'or\nSection|or\nSECTION|or\nSec\.|or\nSecs\.|or\nSEC\.')
        # all_text = re.sub(pattern, remove_line_break_two, all_text)

        # # remove sentence breaks occurring immediately after "and" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
        # pattern = re.compile(r'and\nSection|and\nSECTION|and\nSec\.|and\nSecs\.|and\nSEC\.')
        # all_text = re.sub(pattern, remove_line_break_two, all_text)
        # ##-----------------------------------------------------------------##

        # # remove sentence breaks occurring immediately after "in" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
        # pattern = re.compile(r'in\nArticle|in\nARTICLE|in\nArt\.|in\nART\.')
        # all_text = re.sub(pattern, remove_line_break_two, all_text)

        # # remove sentence breaks occurring immediately after "by" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
        # pattern = re.compile(r'by\nArticle|by\nARTICLE|by\nArt\.|by\nART\.')
        # all_text = re.sub(pattern, remove_line_break_two, all_text)

        # # remove sentence breaks occurring immediately after "or" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
        # pattern = re.compile(r'or\nArticle|or\nARTICLE|or\nArt\.|or\nART\.')
        # all_text = re.sub(pattern, remove_line_break_two, all_text)

        # # remove sentence breaks occurring immediately after "and" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
        # pattern = re.compile(r'and\nArticle|and\nARTICLE|and\nArt\.|and\nART\.')
        # all_text = re.sub(pattern, remove_line_break_two, all_text)
        ##-----------------------------------------------------------------##
        
        # Remove breaks from wrong places caused by §, Section, Article, Division, Subdivision, Chapter, etc.
        sub_string_pattern = "in\n"
        rep_string_pattern = "in "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "or\n"
        rep_string_pattern = "or "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ",\n"
        rep_string_pattern = ", "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ";\n§"
        rep_string_pattern = "; §"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "to\n"
        rep_string_pattern = "to "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "and\n§"
        rep_string_pattern = "and §"
        # sub_string_pattern = "and§"
        # rep_string_pattern = "and\n§"


        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
        ###############################################################
        #  new pattern is added here
        sub_string_pattern = "; and"
        rep_string_pattern = "; and\n"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
        #####################################################################

        sub_string_pattern = "with\n"
        rep_string_pattern = "with "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "per\n"
        rep_string_pattern = "per "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "of\n"
        rep_string_pattern = "of "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "through\n"
        rep_string_pattern = "through "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "by\n"
        rep_string_pattern = "by "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "under\n"
        rep_string_pattern = "under "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "standing\n"
        rep_string_pattern = "standing "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "see\n"
        rep_string_pattern = "see "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "See\n"
        rep_string_pattern = "See "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "for\n"
        rep_string_pattern = "for "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "as\n"
        rep_string_pattern = "as "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "at\n"
        rep_string_pattern = "at "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "excluding\n"
        rep_string_pattern = "excluding "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "ode\n"
        rep_string_pattern = "ode "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "also\n"
        rep_string_pattern = "also "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "this\n"
        rep_string_pattern = "this "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        pattern = re.compile(r'§\n[ ]{0,1}\d')
        all_text = re.sub(pattern, remove_line_break_two, all_text)
        ##-----------------------------------------------------------------##
        sub_string_pattern = "article\n"
        rep_string_pattern = "article "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "section\n"
        rep_string_pattern = "section "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
        ##-----------------------------------------------------------------##

        # all_text = transformZoneNames(all_text)
        # replace double spaces with a single space
        all_text = re.sub(' +', ' ', all_text)

        all_text = re.sub('\n+', '\n', all_text)
        all_text = all_text.split('\n')
        # print("all_text",all_text)
        for iteration, text in enumerate(all_text):
                text = text.strip()
                all_text[iteration] = text
                # print("all_text index by index",all_text[iteration])
        all_text = '\n'.join(all_text)


        return all_text

def municipal_code_textProcessing(all_text):

    # merge all sentences
    all_text = all_text.replace("\n", " ")
    # Correct full stops
    all_text = all_text.replace(" . ", ". ")
    #
    # all_text = all_text.replace("See §", "")
    # remove (Ord. ...)
    # all_text = re.sub('\(Ord.*?\)\D.*?\)', '', all_text)
    # all_text = re.sub('\(\sOrd\. No\..*?\)', '', all_text)
    # all_text = re.sub('\(Ord.*?\)', '', all_text)
    # # remove [Added ...]
    # all_text = re.sub('\(Code.*?\)', '', all_text)
    # # remove [Amended ...]
    # all_text = re.sub('\(P\.A\..*?\)', '', all_text)
    # # remove Editor's Note
    # all_text = re.sub("\[.\] Editor's Note:", '', all_text)
    # # remove [.] Editor's Note: See ...
    # all_text = re.sub("\[.\] Editor's Note: See?.*\.", '', all_text)
    # replace [Sec.] with Sec.
    all_text = re.sub("\[Sec.\]", 'Sec.', all_text)
    # replace [Sec. with Sec.
    all_text = re.sub("\[Sec.", 'Sec.', all_text)
    # replace double spaces with a single space
    all_text = re.sub(' +', ' ', all_text)
    # Break after year and paranthesis, e.g. 1996)
    # all_text = re.sub('\d\d\d\d\)\s\d', '\n', all_text)
    # tokenize into sentences
    all_text = sent_tokenize(all_text)
    for iteration, text in enumerate(all_text):
        text = text.strip()
        all_text[iteration] = text
    # merge all tokeized sentences
    all_text = '\n'.join(all_text)
    all_text = all_text.replace(" § ", "\n§ ")
    all_text = all_text.replace(" §", "\n§")

    # Break sentences at appropriate uppercased and lowercased bullets
    roman_numerals = ["ii", "iii", "iv", "vi", "vii", "viii", "ix"]

    for roman_numeral in roman_numerals:
        sub_string_pattern = "\n" + roman_numeral + "." + "\n"
        rep_string_pattern = "\n" + roman_numeral + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; (" + roman_numeral + ") "
        rep_string_pattern = ";\n(" + roman_numeral + ") "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + roman_numeral + ".\n"
        rep_string_pattern = ";\n" + roman_numeral + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; and " + roman_numeral + ".\n"
        rep_string_pattern = "; and\n" + roman_numeral + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    all_upper_alphabets = list(string.ascii_uppercase)
    all_lower_alphabets = list(string.ascii_lowercase)

    for iteration, item in enumerate(all_lower_alphabets):
        sub_string_pattern = "\n" + item + "." + "\n"
        rep_string_pattern = "\n" + item + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": " + item + "." + "\n"
        rep_string_pattern = ":\n" + item + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": " + item + "." + " "
        rep_string_pattern = ":\n" + item + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = " " + item + "." + "\n"
        rep_string_pattern = "\n" + item + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": (" + item + ")"
        rep_string_pattern = ":\n(" + item + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + item + ")"
        rep_string_pattern = ";\n" + item + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + item + ". "
        rep_string_pattern = ";\n" + item + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; and " + item + ". "
        rep_string_pattern = "; and\n" + item + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + item + item + ". "
        rep_string_pattern = ";\n" + item + item + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + item + item + ".\n"
        rep_string_pattern = ";\n" + item + item + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "\n" + item + item + ".\n"
        rep_string_pattern = "\n" + item + item + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; (" + item + ")"
        rep_string_pattern = ";\n(" + item + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + "\n"
        rep_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": " + all_upper_alphabets[iteration] + "." + "\n"
        rep_string_pattern = ":\n" + all_upper_alphabets[iteration] + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": " + all_upper_alphabets[iteration] + "." + " "
        rep_string_pattern = ":\n" + all_upper_alphabets[iteration] + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = " " + all_upper_alphabets[iteration] + "." + "\n"
        rep_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": (" + all_upper_alphabets[iteration] + ")"
        rep_string_pattern = ":\n(" + all_upper_alphabets[iteration] + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + all_upper_alphabets[iteration] + ")"
        rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + all_upper_alphabets[iteration] + ". "
        rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; and " + all_upper_alphabets[iteration] + ". "
        rep_string_pattern = "; and\n" + all_upper_alphabets[iteration] + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
        rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ".\n"
        rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ".\n"
        rep_string_pattern = "\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; (" + all_upper_alphabets[iteration] + ")"
        rep_string_pattern = ";\n(" + all_upper_alphabets[iteration] + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    # Break sentence at appropriate numbered bullets
    for num in range(1, 100):

        sub_string_pattern = ": (" + str(num) + ")"
        rep_string_pattern = ":\n(" + str(num) + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "\n" + str(num) + "." + "\n"
        rep_string_pattern = "\n" + str(num) + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = " (" + str(num) + ") "
        rep_string_pattern = "\n(" + str(num) + ") "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = " " + str(num) + ".\n"
        rep_string_pattern = "\n" + str(num) + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + str(num) + ")"
        rep_string_pattern = ";\n" + str(num) + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    ## -----------------------------------------------------------------##
    # remove wrong breaks occured during bullet corrections
    # pattern = re.compile(r' chapter\n')
    # all_text = re.sub(pattern, repl, all_text)

    ## -----------------------------------------------------------------##
    # Insert line breaks

    # insert line break for numerical bullet point of arbitrary length
    # pattern = re.compile(r' [\d\-\. ]{4,15} | [\d\-\. ]{4,15}\n')
    pattern = re.compile(r'[^,] [\d\-\.\:]{4,15} |[^,] [\d\-\.\:]{4,15}\n')
    all_text = re.sub(pattern, insert_line_break_two, all_text)

    # insert line breaks for numerical bullets with length less than 4
    pattern = re.compile(r' \d[\.\-\:]{1,1}\d[\.\-\:]{0,1} ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r'[ \n]\d[\w\-\.]{4,15}:')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r'[a-zA-Z]: [A-Z]')
    all_text = re.sub(pattern, insert_line_break_colon, all_text)

    sub_string_pattern = "Sections: "
    rep_string_pattern = "Sections:\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = " Footnotes:"
    rep_string_pattern = "\nFootnotes:"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = " Secs."
    rep_string_pattern = "\nSecs."
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = " )"
    rep_string_pattern = ")"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "\nFeet "
    rep_string_pattern = "\nFeet\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    pattern = re.compile(r"editor's note", re.IGNORECASE)
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r' Sec.[ \n]')
    all_text = re.sub(pattern, repl, all_text)

    ## -----------------------------------------------------------------##
    # break sentences at keyword "Chapter" or "CHAPTER" or "Chap." or "CHAP."
    pattern = re.compile(r' Chapter | CHAPTER | Chap\. | CHAP\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Article" or "ARTICLE" or "Art." or "ART."
    pattern = re.compile(r' Article | ARTICLE | Art\. | ART\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Division" or "DIVISION" or "Div." or "DIV."
    pattern = re.compile(r' Division | DIVISION ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r' Div\. | DIV\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
    pattern = re.compile(r' Subdivision | SUBDIVISION | SUB-DIVISION | Sub-Division ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Part" or "PART"
    pattern = re.compile(r' Part | PART ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Section" or "SECTION" or "SEC." or "Sec."
    pattern = re.compile(r' Section | SECTION ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r' SEC\. | Sec\. | Secs\.')
    all_text = re.sub(pattern, insert_line_break, all_text)
    ## -----------------------------------------------------------------##
    pattern = re.compile(r'[ \-]{0,1}\d\d\d\d\) ')
    all_text = re.sub(pattern, repl_two, all_text)

    pattern = re.compile(r'\w\. \w\. ')
    all_text = re.sub(pattern, insert_line_break_two, all_text)
    ## -----------------------------------------------------------------##

    all_text = re.sub('\n+', '\n', all_text)

    sub_string_pattern = "\n "
    rep_string_pattern = "\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    all_text = all_text.split('\n')
    for iteration, text in enumerate(all_text):
        text = text.strip()
        all_text[iteration] = text
    all_text = '\n'.join(all_text)

    # Remove line breaks

    # remove line break for numerical bullet point of arbitrary length
    pattern = re.compile(r'[\d\-\.]{2,15}\n[a-zA-Z\-]{2,2}')
    all_text = re.sub(pattern, remove_line_break_two, all_text)

    pattern = re.compile(r'Division\n|DIVISION\n')
    all_text = re.sub(pattern, repl, all_text)

    sub_string_pattern = "Sec.\n"
    rep_string_pattern = "Sec. "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    ## -----------------------------------------------------------------##
    # remove sentence breaks occurring immediately after keywords "Chapter" or "CHAPTER" or "Chap." or "CHAP."
    pattern = re.compile(r'\nChapter\n| Chapter\n|Chapter\n|\nCHAPTER\n| CHAPTER\n|CHAPTER\n')
    all_text = re.sub(pattern, repl, all_text)

    pattern = re.compile(r'\nChap\.\n| Chap\.\n|Chap\.\n|\nCHAP\.\n| CHAP\.\n|CHAP\.\n')
    all_text = re.sub(pattern, repl, all_text)

    # remove sentence breaks occurring immediately after keywords "Article" or "ARTICLE" or "Art." or "ART."
    pattern = re.compile(r'\nArticle\n| Article\n|Article\n|\nARTICLE\n| ARTICLE\n|ARTICLE\n')
    all_text = re.sub(pattern, repl, all_text)

    pattern = re.compile(r'\nArt\.\n| Art\.\n|Art\.\n|\nART\.\n| ART\.\n|ART\.\n')
    all_text = re.sub(pattern, repl, all_text)

    # remove sentence breaks occurring immediately after keywords "Division" or "DIVISION" or "Div." or "DIV."
    pattern = re.compile(r'\nDivision\n| Division\n|Division\n|\nDIVISION\n| DIVISION\n|DIVISION\n')
    all_text = re.sub(pattern, repl, all_text)

    pattern = re.compile(r'\nDiv\.\n| Div\.\n|Div\.\n|\nDIV\.\n| DIV.\n|DIV\.\n')
    all_text = re.sub(pattern, repl, all_text)

    # remove sentence breaks occurring immediately after keywords "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
    pattern = re.compile(r'\nSubdivision\n| Subdivision\n|Subdivision\n|\nSUBDIVISION\n| SUBDIVISION\n|SUBDIVISION\n')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r'\nSub-Division\n| Sub-Division\n|Sub-Division\n|\nSUB-DIVISION\n| SUB-DIVISION\n|SUB-DIVISION\n')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # remove sentence breaks occurring immediately after keywords "Part" or "PART"
    pattern = re.compile(r'\nPart\n| Part\n|Part\n|\nPART\n| PART\n|PART\n')
    all_text = re.sub(pattern, repl, all_text)

    # remove sentence breaks occurring immediately after keywords "Section" or "SECTION" or "SEC." or "Sec." or "Secs."
    pattern = re.compile(r'\nSection\n| Section\n|Section\n|\nSECTION\n| SECTION\n|SECTION\n| Sections\n')
    all_text = re.sub(pattern, repl, all_text)

    pattern = re.compile(r'\nSec\.\n| Sec\.\n|Sec\.\n|\nSecs\.\n| Secs\.\n|Secs\.\n|\nSEC\.\n| SEC\.\n|SEC\.\n')
    all_text = re.sub(pattern, repl, all_text)
    ## -----------------------------------------------------------------##

    # remove sentence breaks occurring immediately after keywords "Article I./1." or "ARTICLE I./1."
    pattern = re.compile(r'\nArticle [\w\.\-]{1,25}\n')
    all_text = re.sub(pattern, repl, all_text)
    ## -----------------------------------------------------------------##

    pattern = re.compile(r'[\.\:]\n\-')
    all_text = re.sub(pattern, remove_line_break, all_text)

    # break sentence at Table 5.
    pattern = re.compile(r'Table[ \n]\w\.')
    all_text = re.sub(pattern, repl_two, all_text)

    ## -----------------------------------------------------------------##

    ## -----------------------------------------------------------------##

    # Break at "reserved"
    sub_string_pattern = "(Reserved) "
    rep_string_pattern = "(Reserved)\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "Reserved "
    rep_string_pattern = "Reserved\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "\nFeet"
    rep_string_pattern = " Feet"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
    ## -----------------------------------------------------------------##

    # Remove strings

    sub_string_pattern = "Sections:"
    rep_string_pattern = ""
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "modified\n"
    rep_string_pattern = "\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    ## -----------------------------------------------------------------##
    all_text = re.sub('\n+', '\n', all_text)

    sub_string_pattern = "\n "
    rep_string_pattern = "\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
    ## -----------------------------------------------------------------##

    # Insert line breaks 2 (again)

    # Break line at YEAR (problematic in few cases)
    # pattern = re.compile(r'\d\d\d\d[\)\.]{1,1} ')
    # all_text = re.sub(pattern, repl_two, all_text)

    # break sentences at keyword "Chapter" or "CHAPTER" or "Chap." or "CHAP."
    pattern = re.compile(r' Chapter | CHAPTER | Chap\. | CHAP\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Article" or "ARTICLE" or "Art." or "ART."
    pattern = re.compile(r' Article | ARTICLE | Art\. | ART\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Division" or "DIVISION" or "Div." or "DIV."
    pattern = re.compile(r' Division | DIVISION ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
    pattern = re.compile(r' Subdivision | SUBDIVISION | SUB-DIVISION | Sub-Division ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r' Div\. | DIV\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Part" or "PART"
    pattern = re.compile(r' Part | PART ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Section" or "SECTION" or "SEC." or "Sec."
    pattern = re.compile(r' Section | SECTION ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r' SEC\. | Sec\. | Secs\.')
    all_text = re.sub(pattern, insert_line_break, all_text)
    ## -----------------------------------------------------------------##

    ## -----------------------------------------------------------------##
    # Remove extra line breaks

    all_text = re.sub('\n+', '\n', all_text)

    sub_string_pattern = "\n "
    rep_string_pattern = "\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    # # remove sentence breaks occurring immediately after "in" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
    # pattern = re.compile(r'in\nSection|in\nSECTION|in\nSec\.|in\nSecs\.|in\nSEC\.')
    # all_text = re.sub(pattern, remove_line_break_two, all_text)

    # # remove sentence breaks occurring immediately after "by" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
    # pattern = re.compile(r'by\nSection|by\nSECTION|by\nSec\.|by\nSecs\.|by\nSEC\.')
    # all_text = re.sub(pattern, remove_line_break_two, all_text)

    # # remove sentence breaks occurring immediately after "or" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
    # pattern = re.compile(r'or\nSection|or\nSECTION|or\nSec\.|or\nSecs\.|or\nSEC\.')
    # all_text = re.sub(pattern, remove_line_break_two, all_text)

    # # remove sentence breaks occurring immediately after "and" and containing "Section" or "SECTION" or "SEC." or "Sec." or "Secs." in next line
    # pattern = re.compile(r'and\nSection|and\nSECTION|and\nSec\.|and\nSecs\.|and\nSEC\.')
    # all_text = re.sub(pattern, remove_line_break_two, all_text)
    # ##-----------------------------------------------------------------##

    # # remove sentence breaks occurring immediately after "in" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
    # pattern = re.compile(r'in\nArticle|in\nARTICLE|in\nArt\.|in\nART\.')
    # all_text = re.sub(pattern, remove_line_break_two, all_text)

    # # remove sentence breaks occurring immediately after "by" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
    # pattern = re.compile(r'by\nArticle|by\nARTICLE|by\nArt\.|by\nART\.')
    # all_text = re.sub(pattern, remove_line_break_two, all_text)

    # # remove sentence breaks occurring immediately after "or" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
    # pattern = re.compile(r'or\nArticle|or\nARTICLE|or\nArt\.|or\nART\.')
    # all_text = re.sub(pattern, remove_line_break_two, all_text)

    # # remove sentence breaks occurring immediately after "and" and containing "Article" or "ARTICLE" or "ART." or "Art." in next line
    # pattern = re.compile(r'and\nArticle|and\nARTICLE|and\nArt\.|and\nART\.')
    # all_text = re.sub(pattern, remove_line_break_two, all_text)
    ## -----------------------------------------------------------------##

    # Remove breaks from wrong places caused by §, Section, Article, Division, Subdivision, Chapter, etc.
    sub_string_pattern = "in\n"
    rep_string_pattern = "in "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "or\n"
    rep_string_pattern = "or "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = ",\n"
    rep_string_pattern = ", "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = ";\n§"
    rep_string_pattern = "; §"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "to\n"
    rep_string_pattern = "to "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "and\n§"
    rep_string_pattern = "and §"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "with\n"
    rep_string_pattern = "with "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "per\n"
    rep_string_pattern = "per "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "of\n"
    rep_string_pattern = "of "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "through\n"
    rep_string_pattern = "through "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "by\n"
    rep_string_pattern = "by "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "under\n"
    rep_string_pattern = "under "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "standing\n"
    rep_string_pattern = "standing "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "see\n"
    rep_string_pattern = "see "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "See\n"
    rep_string_pattern = "See "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "for\n"
    rep_string_pattern = "for "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "as\n"
    rep_string_pattern = "as "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "at\n"
    rep_string_pattern = "at "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "excluding\n"
    rep_string_pattern = "excluding "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "ode\n"
    rep_string_pattern = "ode "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "also\n"
    rep_string_pattern = "also "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "this\n"
    rep_string_pattern = "this "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    pattern = re.compile(r'§\n[ ]{0,1}\d')
    all_text = re.sub(pattern, remove_line_break_two, all_text)
    ## -----------------------------------------------------------------##
    sub_string_pattern = "article\n"
    rep_string_pattern = "article "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "section\n"
    rep_string_pattern = "section "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
    ## -----------------------------------------------------------------##

    # replace double spaces with a single space
    all_text = re.sub(' +', ' ', all_text)

    all_text = re.sub('\n+', '\n', all_text)
    all_text = all_text.split('\n')
    for iteration, text in enumerate(all_text):
        text = text.strip()
        all_text[iteration] = text
    all_text = '\n'.join(all_text)

    return all_text


def amlegal_textProcessing(all_text):

    # merge all sentences
    all_text = all_text.replace("\n", " ")
    # Correct full stops
    all_text = all_text.replace(" . ", ". ")
    #
    # all_text = all_text.replace("See §", "")
    # remove (Ord. ...)
    # all_text = re.sub('\(Ord.*?\)\D.*?\)', '', all_text)
    # all_text = re.sub('\(\sOrd\. No\..*?\)', '', all_text)
    # all_text = re.sub('\(Ord.*?\)', '', all_text)
    # # remove [Added ...]
    # all_text = re.sub('\(Code.*?\)', '', all_text)
    # # remove [Amended ...]
    # all_text = re.sub('\(P\.A\..*?\)', '', all_text)
    # # remove Editor's Note
    # all_text = re.sub("\[.\] Editor's Note:", '', all_text)
    # # remove [.] Editor's Note: See ...
    # all_text = re.sub("\[.\] Editor's Note: See?.*\.", '', all_text)
    # replace [Sec.] with Sec.
    all_text = re.sub("\[Sec.\]", 'Sec.', all_text)
    # replace [Sec. with Sec.
    all_text = re.sub("\[Sec.", 'Sec.', all_text)
    # replace double spaces with a single space
    all_text = re.sub(' +', ' ', all_text)
    # Break after year and paranthesis, e.g. 1996)
    # all_text = re.sub('\d\d\d\d\)\s\d', '\n', all_text)
    # tokenize into sentences
    all_text = sent_tokenize(all_text)
    for iteration, text in enumerate(all_text):
        text = text.strip()
        all_text[iteration] = text
    # merge all tokeized sentences
    all_text = '\n'.join(all_text)
    all_text = all_text.replace(" § ", "\n§ ")
    all_text = all_text.replace(" §", "\n§")

    # Break sentences at appropriate uppercased and lowercased bullets
    roman_numerals = ["ii", "iii", "iv", "vi", "vii", "viii", "ix"]

    for roman_numeral in roman_numerals:
        sub_string_pattern = "\n" + roman_numeral + "." + "\n"
        rep_string_pattern = "\n" + roman_numeral + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; (" + roman_numeral + ") "
        rep_string_pattern = ";\n(" + roman_numeral + ") "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + roman_numeral + ".\n"
        rep_string_pattern = ";\n" + roman_numeral + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; and " + roman_numeral + ".\n"
        rep_string_pattern = "; and\n" + roman_numeral + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    all_upper_alphabets = list(string.ascii_uppercase)
    all_lower_alphabets = list(string.ascii_lowercase)

    for iteration, item in enumerate(all_lower_alphabets):
        sub_string_pattern = "\n" + item + "." + "\n"
        rep_string_pattern = "\n" + item + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": " + item + "." + "\n"
        rep_string_pattern = ":\n" + item + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": " + item + "." + " "
        rep_string_pattern = ":\n" + item + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = " " + item + "." + "\n"
        rep_string_pattern = "\n" + item + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": (" + item + ")"
        rep_string_pattern = ":\n(" + item + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + item + ")"
        rep_string_pattern = ";\n" + item + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + item + ". "
        rep_string_pattern = ";\n" + item + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; and " + item + ". "
        rep_string_pattern = "; and\n" + item + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + item + item + ". "
        rep_string_pattern = ";\n" + item + item + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + item + item + ".\n"
        rep_string_pattern = ";\n" + item + item + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "\n" + item + item + ".\n"
        rep_string_pattern = "\n" + item + item + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; (" + item + ")"
        rep_string_pattern = ";\n(" + item + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + "\n"
        rep_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": " + all_upper_alphabets[iteration] + "." + "\n"
        rep_string_pattern = ":\n" + all_upper_alphabets[iteration] + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": " + all_upper_alphabets[iteration] + "." + " "
        rep_string_pattern = ":\n" + all_upper_alphabets[iteration] + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = " " + all_upper_alphabets[iteration] + "." + "\n"
        rep_string_pattern = "\n" + all_upper_alphabets[iteration] + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = ": (" + all_upper_alphabets[iteration] + ")"
        rep_string_pattern = ":\n(" + all_upper_alphabets[iteration] + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + all_upper_alphabets[iteration] + ")"
        rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + all_upper_alphabets[iteration] + ". "
        rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; and " + all_upper_alphabets[iteration] + ". "
        rep_string_pattern = "; and\n" + all_upper_alphabets[iteration] + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
        rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ".\n"
        rep_string_pattern = ";\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ".\n"
        rep_string_pattern = "\n" + all_upper_alphabets[iteration] + all_upper_alphabets[iteration] + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; (" + all_upper_alphabets[iteration] + ")"
        rep_string_pattern = ";\n(" + all_upper_alphabets[iteration] + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    # Break sentence at appropriate numbered bullets
    for num in range(1, 100):

        sub_string_pattern = ": (" + str(num) + ")"
        rep_string_pattern = ":\n(" + str(num) + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "\n" + str(num) + "." + "\n"
        rep_string_pattern = "\n" + str(num) + "." + " "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = " (" + str(num) + ") "
        rep_string_pattern = "\n(" + str(num) + ") "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = " " + str(num) + ".\n"
        rep_string_pattern = "\n" + str(num) + ". "
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

        sub_string_pattern = "; " + str(num) + ")"
        rep_string_pattern = ";\n" + str(num) + ")"
        all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    ## -----------------------------------------------------------------##
    # remove wrong breaks occured during bullet corrections
    # pattern = re.compile(r' chapter\n')
    # all_text = re.sub(pattern, repl, all_text)

    ## -----------------------------------------------------------------##
    # Insert line breaks

    # insert line break for numerical bullet point of arbitrary length
    # pattern = re.compile(r' [\d\-\. ]{4,15} | [\d\-\. ]{4,15}\n')
    pattern = re.compile(r'[^,] [\d\-\.\:]{4,15} |[^,] [\d\-\.\:]{4,15}\n')
    all_text = re.sub(pattern, insert_line_break_two, all_text)

    # insert line breaks for numerical bullets with length less than 4
    pattern = re.compile(r' \d[\.\-\:]{1,1}\d[\.\-\:]{0,1} ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r'[ \n]\d[\w\-\.]{4,15}:')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r'[a-zA-Z]: [A-Z]')
    all_text = re.sub(pattern, insert_line_break_colon, all_text)

    sub_string_pattern = "Sections: "
    rep_string_pattern = "Sections:\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = " Footnotes:"
    rep_string_pattern = "\nFootnotes:"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = " Secs."
    rep_string_pattern = "\nSecs."
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = " )"
    rep_string_pattern = ")"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "\nFeet "
    rep_string_pattern = "\nFeet\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    pattern = re.compile(r"editor's note", re.IGNORECASE)
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r' Sec.[ \n]')
    all_text = re.sub(pattern, repl, all_text)

    ## -----------------------------------------------------------------##
    # break sentences at keyword "Chapter" or "CHAPTER" or "Chap." or "CHAP."
    pattern = re.compile(r' Chapter | CHAPTER | Chap\. | CHAP\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Article" or "ARTICLE" or "Art." or "ART."
    pattern = re.compile(r' Article | ARTICLE | Art\. | ART\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Division" or "DIVISION" or "Div." or "DIV."
    pattern = re.compile(r' Division | DIVISION ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r' Div\. | DIV\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
    pattern = re.compile(r' Subdivision | SUBDIVISION | SUB-DIVISION | Sub-Division ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Part" or "PART"
    pattern = re.compile(r' Part | PART ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Section" or "SECTION" or "SEC." or "Sec."
    pattern = re.compile(r' Section | SECTION ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r' SEC\. | Sec\. | Secs\.')
    all_text = re.sub(pattern, insert_line_break, all_text)
    ## -----------------------------------------------------------------##
    pattern = re.compile(r'[ \-]{0,1}\d\d\d\d\) ')
    all_text = re.sub(pattern, repl_two, all_text)

    pattern = re.compile(r'\w\. \w\. ')
    all_text = re.sub(pattern, insert_line_break_two, all_text)
    ## -----------------------------------------------------------------##

    all_text = re.sub('\n+', '\n', all_text)

    sub_string_pattern = "\n "
    rep_string_pattern = "\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    all_text = all_text.split('\n')
    for iteration, text in enumerate(all_text):
        text = text.strip()
        all_text[iteration] = text
    all_text = '\n'.join(all_text)

    # Remove line breaks

    # remove line break for numerical bullet point of arbitrary length
    pattern = re.compile(r'[\d\-\.]{2,15}\n[a-zA-Z\-]{2,2}')
    all_text = re.sub(pattern, remove_line_break_two, all_text)

    pattern = re.compile(r'Division\n|DIVISION\n')
    all_text = re.sub(pattern, repl, all_text)

    sub_string_pattern = "Sec.\n"
    rep_string_pattern = "Sec. "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    ## -----------------------------------------------------------------##
    # remove sentence breaks occurring immediately after keywords "Chapter" or "CHAPTER" or "Chap." or "CHAP."
    pattern = re.compile(r'\nChapter\n| Chapter\n|Chapter\n|\nCHAPTER\n| CHAPTER\n|CHAPTER\n')
    all_text = re.sub(pattern, repl, all_text)

    pattern = re.compile(r'\nChap\.\n| Chap\.\n|Chap\.\n|\nCHAP\.\n| CHAP\.\n|CHAP\.\n')
    all_text = re.sub(pattern, repl, all_text)

    # remove sentence breaks occurring immediately after keywords "Article" or "ARTICLE" or "Art." or "ART."
    pattern = re.compile(r'\nArticle\n| Article\n|Article\n|\nARTICLE\n| ARTICLE\n|ARTICLE\n')
    all_text = re.sub(pattern, repl, all_text)

    pattern = re.compile(r'\nArt\.\n| Art\.\n|Art\.\n|\nART\.\n| ART\.\n|ART\.\n')
    all_text = re.sub(pattern, repl, all_text)

    # remove sentence breaks occurring immediately after keywords "Division" or "DIVISION" or "Div." or "DIV."
    pattern = re.compile(r'\nDivision\n| Division\n|Division\n|\nDIVISION\n| DIVISION\n|DIVISION\n')
    all_text = re.sub(pattern, repl, all_text)

    pattern = re.compile(r'\nDiv\.\n| Div\.\n|Div\.\n|\nDIV\.\n| DIV.\n|DIV\.\n')
    all_text = re.sub(pattern, repl, all_text)

    # remove sentence breaks occurring immediately after keywords "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
    pattern = re.compile(r'\nSubdivision\n| Subdivision\n|Subdivision\n|\nSUBDIVISION\n| SUBDIVISION\n|SUBDIVISION\n')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r'\nSub-Division\n| Sub-Division\n|Sub-Division\n|\nSUB-DIVISION\n| SUB-DIVISION\n|SUB-DIVISION\n')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # remove sentence breaks occurring immediately after keywords "Part" or "PART"
    pattern = re.compile(r'\nPart\n| Part\n|Part\n|\nPART\n| PART\n|PART\n')
    all_text = re.sub(pattern, repl, all_text)

    # remove sentence breaks occurring immediately after keywords "Section" or "SECTION" or "SEC." or "Sec." or "Secs."
    pattern = re.compile(r'\nSection\n| Section\n|Section\n|\nSECTION\n| SECTION\n|SECTION\n| Sections\n')
    all_text = re.sub(pattern, repl, all_text)

    pattern = re.compile(r'\nSec\.\n| Sec\.\n|Sec\.\n|\nSecs\.\n| Secs\.\n|Secs\.\n|\nSEC\.\n| SEC\.\n|SEC\.\n')
    all_text = re.sub(pattern, repl, all_text)
    ## -----------------------------------------------------------------##

    # remove sentence breaks occurring immediately after keywords "Article I./1." or "ARTICLE I./1."
    pattern = re.compile(r'\nArticle [\w\.\-]{1,25}\n')
    all_text = re.sub(pattern, repl, all_text)
    ## -----------------------------------------------------------------##

    pattern = re.compile(r'[\.\:]\n\-')
    all_text = re.sub(pattern, remove_line_break, all_text)

    # break sentence at Table 5.
    pattern = re.compile(r'Table[ \n]\w\.')
    all_text = re.sub(pattern, repl_two, all_text)

    ## -----------------------------------------------------------------##

    ## -----------------------------------------------------------------##

    # Break at "reserved"
    sub_string_pattern = "(Reserved) "
    rep_string_pattern = "(Reserved)\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "Reserved "
    rep_string_pattern = "Reserved\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "\nFeet"
    rep_string_pattern = " Feet"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
    ## -----------------------------------------------------------------##

    # Remove strings

    sub_string_pattern = "Sections:"
    rep_string_pattern = ""
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "modified\n"
    rep_string_pattern = "\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    ## -----------------------------------------------------------------##
    all_text = re.sub('\n+', '\n', all_text)

    sub_string_pattern = "\n "
    rep_string_pattern = "\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
    ## -----------------------------------------------------------------##

    # Insert line breaks 2 (again)

    # Break line at YEAR (problematic in few cases)
    # pattern = re.compile(r'\d\d\d\d[\)\.]{1,1} ')
    # all_text = re.sub(pattern, repl_two, all_text)

    # break sentences at keyword "Chapter" or "CHAPTER" or "Chap." or "CHAP."
    pattern = re.compile(r' Chapter | CHAPTER | Chap\. | CHAP\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Article" or "ARTICLE" or "Art." or "ART."
    pattern = re.compile(r' Article | ARTICLE | Art\. | ART\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Division" or "DIVISION" or "Div." or "DIV."
    pattern = re.compile(r' Division | DIVISION ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Subdivision" or "SUBDIVISION" or "SUB-DIVISION" or "Sub-Division"
    pattern = re.compile(r' Subdivision | SUBDIVISION | SUB-DIVISION | Sub-Division ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r' Div\. | DIV\. ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Part" or "PART"
    pattern = re.compile(r' Part | PART ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    # break sentences at keyword "Section" or "SECTION" or "SEC." or "Sec."
    pattern = re.compile(r' Section | SECTION ')
    all_text = re.sub(pattern, insert_line_break, all_text)

    pattern = re.compile(r' SEC\. | Sec\. | Secs\.')
    all_text = re.sub(pattern, insert_line_break, all_text)
    ## -----------------------------------------------------------------##

    ## -----------------------------------------------------------------##
    # Remove extra line breaks

    all_text = re.sub('\n+', '\n', all_text)

    sub_string_pattern = "\n "
    rep_string_pattern = "\n"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    # Remove breaks from wrong places caused by §, Section, Article, Division, Subdivision, Chapter, etc.
    sub_string_pattern = "in\n"
    rep_string_pattern = "in "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "or\n"
    rep_string_pattern = "or "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = ",\n"
    rep_string_pattern = ", "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = ";\n§"
    rep_string_pattern = "; §"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "to\n"
    rep_string_pattern = "to "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "and\n§"
    rep_string_pattern = "and §"
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "with\n"
    rep_string_pattern = "with "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "per\n"
    rep_string_pattern = "per "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "of\n"
    rep_string_pattern = "of "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "through\n"
    rep_string_pattern = "through "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "by\n"
    rep_string_pattern = "by "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "under\n"
    rep_string_pattern = "under "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "standing\n"
    rep_string_pattern = "standing "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "see\n"
    rep_string_pattern = "see "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "See\n"
    rep_string_pattern = "See "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "for\n"
    rep_string_pattern = "for "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "as\n"
    rep_string_pattern = "as "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "at\n"
    rep_string_pattern = "at "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "excluding\n"
    rep_string_pattern = "excluding "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "ode\n"
    rep_string_pattern = "ode "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "also\n"
    rep_string_pattern = "also "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "this\n"
    rep_string_pattern = "this "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    pattern = re.compile(r'§\n[ ]{0,1}\d')
    all_text = re.sub(pattern, remove_line_break_two, all_text)
    ## -----------------------------------------------------------------##
    sub_string_pattern = "article\n"
    rep_string_pattern = "article "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)

    sub_string_pattern = "section\n"
    rep_string_pattern = "section "
    all_text = all_text.replace(sub_string_pattern, rep_string_pattern)
    ## -----------------------------------------------------------------##

    # replace double spaces with a single space
    all_text = re.sub(' +', ' ', all_text)

    all_text = re.sub('\n+', '\n', all_text)
    all_text = all_text.split('\n')
    for iteration, text in enumerate(all_text):
        text = text.strip()
        all_text[iteration] = text
    all_text = '\n'.join(all_text)

    return all_text
