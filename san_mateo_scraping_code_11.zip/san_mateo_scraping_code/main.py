from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import json
from urllib.parse import urlparse
from utils import *



url = "https://law.cityofsanmateo.org/us/ca/cities/san-mateo/code/27"
parsed_url = urlparse(url)
base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
print(base_url)



###########################################################################

# Set up your WebDriver (example: Chrome)
driver = webdriver.Chrome()  # Make sure chromedriver is in your PATH
driver.get("https://law.cityofsanmateo.org/us/ca/cities/san-mateo/code/27")  # Replace with the actual page URL
 
chapter_links_xpath = "//div[@class='toc-menu']/ul/li/ul/li[27]/ul/li"
 
chapter_links = driver.find_elements(By.XPATH, chapter_links_xpath)
results = {}
 
for iter, chapter_link in enumerate(chapter_links):
    title_count = iter + 1
    chapter_link.click()

    chapter_title_1 = chapter_link.text.strip()
    extracting_number = chapter_title_1.split()
    chapter_number = extracting_number[1]
    time.sleep(3)
 
    chapter_title_xpath = f"//h2[@id='/us/ca/cities/san-mateo/code/27.19']"
    chapter_title_element = driver.find_elements(By.XPATH, chapter_title_xpath)
 
    if chapter_title_element:
        chapter_title = chapter_title_element[0].text

    article_path = '//div[@class="tuf-authenticate"]//*[@class="h__article"]'
    article_path_elements = driver.find_elements(By. XPATH, f"{article_path}")

    article_title = article_path_elements[0].text



    if not article_path_elements:
        article_path = "//*[contains(@class, 'h__section') and contains(@id, '/us/ca/cities/san-mateo/code/27.19')]/preceding-sibling::h2[1]"
        article_path_elements = driver.find_elements(By. XPATH, f"{article_path}")

    if article_path_elements:
        for article in article_path_elements:
 
            # Find all <h3> elements matching the zoning code ID pattern
            # h3_elements = driver.find_elements(By.XPATH, f"//h3[starts-with(@id, '/us/ca/cities/san-mateo/code/{chapter_number}')]")
            h3_elements = driver.find_elements(By.XPATH, f"//*[contains(@class, 'h__section') and contains(@id, '/us/ca/cities/san-mateo/code/27.19')]")
            
        
            for i, h3 in enumerate(h3_elements, 1):
                id = h3.get_attribute("id")
                section_url = base_url + id
                section_index = 1
                file_number = f"{title_count}.{i}"

                section = {
                    "heading": h3.text.strip(),
                    "id": id,
                    "url": section_url,
                    "file": file_number,
                    "html": "",
                    "text": ""
                }

                paragraphs_html = []
                paragraphs_text = []
                sibling = h3.find_element(By.XPATH, "following-sibling::*[1]")

                while sibling.tag_name not in ['h2', 'h3']:
                    try:
                        tag = sibling.tag_name.lower()
                        cls = sibling.get_attribute("class")

                        if tag == 'p':
                            paragraphs_text.append(sibling.text.strip())
                            paragraphs_html.append(sibling.get_attribute('outerHTML'))

                        elif tag == 'div' and 'table_wrap' in cls:
                            # paragraphs_text.append(sibling.text.strip())
                            # paragraphs_html.append(sibling.get_attribute('outerHTML'))
                            table_element = sibling.find_element(By.TAG_NAME, 'table')  # <== This gives you the <table> Selenium WebElement
                            table_text = table_element.text
                            table_html = table_element.get_attribute("outerHTML")
                            print("table html",table_element.get_attribute("outerHTML"))
                            # Optionally, use your table processing function here
                            markdown_text = table_to_markdown_with_chunks(table_element)
                            if markdown_text:
                                paragraphs_text.append(markdown_text)

                            # Always append raw HTML as fallback
                            paragraphs_html.append(sibling.get_attribute('outerHTML'))

                        # Move to the next sibling
                        sibling = sibling.find_element(By.XPATH, "following-sibling::*[1]")

                    except:
                        break
        
    else:
                # Find all <h3> elements matching the zoning code ID pattern
        # h3_elements = driver.find_elements(By.XPATH, f"//h3[starts-with(@id, '/us/ca/cities/san-mateo/code/{chapter_number}')]")
        h3_elements = driver.find_elements(By.XPATH, f"//*[contains(@class, 'h__section') and contains(@id, '/us/ca/cities/san-mateo/code/{chapter_number}')]")
        
    
        for i, h3 in enumerate(h3_elements, 1):
            id = h3.get_attribute("id")
            section_url = base_url + id
            section_index = 1
            file_number = f"{title_count}.{i}"

            section = {
                "heading": h3.text.strip(),
                "id": id,
                "url": section_url,
                "file": file_number,
                "html": "",
                "text": ""
            }

            paragraphs_html = []
            paragraphs_text = []
            sibling = h3.find_element(By.XPATH, "following-sibling::*[1]")

            while sibling.tag_name not in ['h2', 'h3']:
                try:
                    tag = sibling.tag_name.lower()
                    cls = sibling.get_attribute("class")

                    if tag == 'p':
                        paragraphs_text.append(sibling.text.strip())
                        paragraphs_html.append(sibling.get_attribute('outerHTML'))

                    elif tag == 'div' and 'table_wrap' in cls:
                        # paragraphs_text.append(sibling.text.strip())
                        # paragraphs_html.append(sibling.get_attribute('outerHTML'))
                        table_element = sibling.find_element(By.TAG_NAME, 'table')  # <== This gives you the <table> Selenium WebElement
                        table_text = table_element.text
                        table_html = table_element.get_attribute("outerHTML")
                        print("table html",table_element.get_attribute("outerHTML"))
                        # Optionally, use your table processing function here
                        markdown_text = table_to_markdown_with_chunks(table_element)
                        if markdown_text:
                            paragraphs_text.append(markdown_text)

                        # Always append raw HTML as fallback
                        paragraphs_html.append(sibling.get_attribute('outerHTML'))

                    # Move to the next sibling
                    sibling = sibling.find_element(By.XPATH, "following-sibling::*[1]")

                except:
                    break


        section["html"] = "\n".join(paragraphs_html)
        section["text"] = "\n".join(paragraphs_text)

        # You can now store `section` into your results or use it as needed


        section["html"] = f"<div id='{file_number}'>{' '.join(paragraphs_html)}</div>"
        section["text"] = " ".join(paragraphs_text)

        ###########################################################
        
  
        if chapter_title not in results:
            # chapter_title = chapter_title.lower()
            results[chapter_title] = []
        results[chapter_title].append(section)
        # print("results type",results)
 

transform_structure_content = transform_structure(results)

with open("chapters.json", "w", encoding="utf-8") as f:
    json.dump(transform_structure_content, f, ensure_ascii=False, indent=4)

chapters_wise_jsons(transform_structure_content,results)
generate_csv(transform_structure_content, results)
driver.quit()
 




# //h2[@id="/us/ca/cities/san-mateo/code/27.02" or @class="line subheading"]