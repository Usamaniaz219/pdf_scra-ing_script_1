import json
import re
import os
import time
from urllib.parse import urlparse
from selenium.webdriver.common.by import By
from markdownify import markdownify as md
import math
from collections import Counter

# Load XPaths from config
with open('x_paths/xpath.json') as f:
    XPATHS = json.load(f)

class TableProcessor:
    @staticmethod
    def get_repeated_table_elements(table_elements: list):
        if not table_elements:
            return []
        repeated_tables = []
        i = 0
        while i < len(table_elements) - 1:
            current_text = table_elements[i].text.strip()
            next_text = table_elements[i + 1].text.strip()
            if current_text and current_text in next_text:
                repeated_tables.append(table_elements[i])
                i += 1  
            else:
                i += 1
        return repeated_tables

    @staticmethod
    def get_shared_headings(repeated_tables: list):
        table_texts = [table.text for table in repeated_tables]
        table_duplicates = [item for item, count in Counter(table_texts).items() if count > 1]
        return table_duplicates if table_duplicates else None

    @staticmethod
    def remove_repeated_tables(table_elements):
        if not table_elements:
            return []
        filtered_tables = []
        i = 0
        while i < len(table_elements) - 1:
            current_text = table_elements[i].text.strip()
            next_text = table_elements[i + 1].text.strip()
            if current_text and current_text in next_text:
                i += 1  
            else:
                filtered_tables.append(table_elements[i])
                i += 1
        if i == len(table_elements) - 1:
            filtered_tables.append(table_elements[-1])
        return filtered_tables

    @staticmethod
    def replace_second_occurrence(text, sub, replacement=""):
        first_index = text.find(sub)
        if first_index == -1:
            return text
        second_index = text.find(sub, first_index + len(sub))
        if second_index == -1:
            return text
        return text[:second_index] + replacement + text[second_index + len(sub):]

    @staticmethod
    def remove_repeated_tables_text(page_text, duplicate_tables):
        duplicate_headers = TableProcessor.get_shared_headings(duplicate_tables)
        duplicate_flag = False
        
        if duplicate_headers:
            for table in duplicate_tables:
                table_text = table.text
                if table_text not in duplicate_headers:
                    if table_text in page_text:
                        page_text = page_text.replace(table_text, "", 1)
                    else:
                        print("Table Text Not Found For Duplicate Table")
                else:
                    if duplicate_flag == False:
                        if table_text in page_text:
                            page_text = page_text.replace(table_text,"",1)
                            duplicate_flag = True
                        else:
                            print("Table Text Not Found For Duplicate Table")
            for table_text in duplicate_headers:
                page_text = TableProcessor.replace_second_occurrence(page_text, table_text)
            return page_text
        else:
            for table in duplicate_tables:
                table_text = table.text
                if table_text in page_text:
                    page_text = page_text.replace(table_text, "", 1)
                else:
                    print("Table Text Not Found For Duplicate Table")
            return page_text

    @staticmethod
    def get_large_tables_markdowns(table_elements):
        large_tables_dict = {}
        for index, table_element in enumerate(table_elements):
            table_html = table_element.get_attribute("outerHTML")
            table_markdown = md(table_html, heading_style="ATX", strip=["a"])
            if len(table_markdown) > 6000:
                large_tables_dict[index] = table_markdown
        return large_tables_dict

    @staticmethod
    def get_top_three_lines(table_markdown):
        def has_min_alphanum(line, min_count=3):
            return sum(char.isalnum() for char in line) >= min_count
        
        top_three_lines = []
        table_md_lines = table_markdown.split("\n")
        count = 0
        for line in table_md_lines[:6]:
            if count >=3:
                break
            if has_min_alphanum(line):
                top_three_lines.append(line)
                count += 1
        return "\n".join(top_three_lines)

    @staticmethod
    def update_large_table_markdown(large_table_markdown):
        full_table_markdown = ""
        start_phrase = "\nTABLE STARTS HERE\n"
        end_phrase = "\nTABLE ENDS HERE\n"
        table_md_length = len(large_table_markdown)
        chunk_size = 4000
        num_splits = math.ceil(table_md_length / chunk_size)
        large_table_markdown_lines = large_table_markdown.split("\n")
        lines_in_table_md = len(large_table_markdown_lines)
        top_three_lines = TableProcessor.get_top_three_lines(large_table_markdown)
        lines_per_md = lines_in_table_md // num_splits
        remainder_lines = lines_in_table_md % num_splits
        start_idx = 0
        
        for i in range(num_splits):
            end_idx = start_idx + lines_per_md + (1 if i < remainder_lines else 0)
            splitted_md = large_table_markdown_lines[start_idx: end_idx]
            splitted_md = " \n".join(splitted_md)
            if i !=0:
                splitted_md = f"{top_three_lines}\n{splitted_md}"
            full_table_markdown = full_table_markdown + f"{start_phrase}{splitted_md}{end_phrase}"
            start_idx = end_idx
        
        if end_idx != lines_in_table_md:
            print("Some Data is Missed!")
            return None
        return full_table_markdown

    @staticmethod
    def update_original_markdowns_list(large_tables_markdowns, all_markdowns):
        for index, table_markdown in large_tables_markdowns.items():
            updated_markdown = TableProcessor.update_large_table_markdown(table_markdown)
            if updated_markdown is None:
                return None
            all_markdowns[index] = updated_markdown
        return all_markdowns

    @staticmethod
    def large_tables_pipeline(table_elements):
        large_tables_dict = TableProcessor.get_large_tables_markdowns(table_elements)
        all_markdowns = TableProcessor.convert_table_text_to_markdown(table_elements)
        updated_markdowns = TableProcessor.update_original_markdowns_list(large_tables_dict, all_markdowns)
        if updated_markdowns is None:
            print("Error in large tables pipeline")
            return None
        return updated_markdowns

    @staticmethod
    def detect_table_in_element(element):
        table_elements = element.find_elements(By.TAG_NAME, "table")
        if table_elements:
            valid_tables = [table for table in table_elements if table.text.strip()]
            if len(valid_tables) > 1:
                unique_tables = TableProcessor.remove_repeated_tables(valid_tables)
                return unique_tables, valid_tables
            return valid_tables, valid_tables
        return None, None

    @staticmethod
    def extract_table_text(table_elements):
        return [table.text for table in table_elements if table.text.strip()]

    @staticmethod
    def convert_table_text_to_markdown(table_elements):
        start_phrase = "\nTABLE STARTS HERE\n"
        end_phrase = "\nTABLE ENDS HERE\n"
        return [
            f"{start_phrase}{md(table.get_attribute('outerHTML'), heading_style='ATX', strip=['a'])}{end_phrase}"
            for table in table_elements
        ]

    @staticmethod
    def replace_table_text_with_dummy_text(page_data, all_tables_text):
        unique_token = "UniQuE_TaBLe_TokEn_TO_bEE_RepLAcEd_LaTEr"
        for table_text in all_tables_text:
            if table_text in page_data:
                page_data = re.sub(re.escape(table_text), unique_token, page_data, count=1)
            else:
                print("Table_Text Not Found!")
        return page_data

    @staticmethod
    def modify_tables_text(table_markdowns, page_data):
        unique_token = "UniQuE_TaBLe_TokEn_TO_bEE_RepLAcEd_LaTEr"
        for markdown in table_markdowns:
            page_data = re.sub(re.escape(unique_token), lambda match: markdown, page_data, count=1)
        return page_data

    @staticmethod
    def table_to_markdown_with_chunks(element):
        valid_tables, all_tables = TableProcessor.detect_table_in_element(element)
        element_text = element.text
        
        if valid_tables:
            tables_markdowns = TableProcessor.convert_table_text_to_markdown(valid_tables)
            large_tables = TableProcessor.get_large_tables_markdowns(valid_tables)
            
            if large_tables:
                tables_markdowns_updated = TableProcessor.large_tables_pipeline(valid_tables)
                if tables_markdowns_updated is None:
                    print("Some Error Processing Large Tables")
                    return None
                tables_markdowns = tables_markdowns_updated
                    
            duplicate_tables = TableProcessor.get_repeated_table_elements(all_tables)
            if duplicate_tables:
                element_text = TableProcessor.remove_repeated_tables_text(element_text, duplicate_tables)

            tables_text = TableProcessor.extract_table_text(valid_tables)
            element_dummy_text = TableProcessor.replace_table_text_with_dummy_text(element_text, tables_text)
            element_text = TableProcessor.modify_tables_text(tables_markdowns, element_dummy_text)
            return element_text
        return element.text

class ContentProcessor:
    @staticmethod
    def transform_structure(data):
        output = []
        for chapter_index, (chapter_title, sections) in enumerate(data.items(), 1):
            match = re.match(r"Chapter\s+([\d.]+)\s+(.*)", chapter_title)
            readable_title = match.group(2).title() if match else chapter_title

            article = {
                "title": f"Chapter {chapter_index} {readable_title}",
                "dir": f"chapter_{chapter_index}",
                "file": "",
                "sections": []
            }

            for i, section in enumerate(sections, 1):
                section_entry = {
                    "title": f"§ {section['heading']}",
                    "file": f"{chapter_index}.{i}",
                    "section": []
                }
                article["sections"].append(section_entry)

            output.append(article)
        return output

    @staticmethod
    def extract_chapter_name(title):
        return re.sub(r'^Chapter\s+\d+\.?\s*', '', title, flags=re.IGNORECASE).strip()

    @staticmethod
    def normalize(text):
        return text.strip().rstrip('.').lower()

    @staticmethod
    def save_chapters_wise_jsons(chapters, results, base_dir="chapter_wise_jsons"):
        os.makedirs(base_dir, exist_ok=True)

        for i, chapter in enumerate(chapters, 1):
            chapter_title = ContentProcessor.extract_chapter_name(chapter["title"])
            chapter_title_normalized = ContentProcessor.normalize(chapter_title.upper())

            matched_chapter_key = next(
                (key for key in results if ContentProcessor.normalize(key).endswith(chapter_title_normalized)),
                None
            )

            if not matched_chapter_key:
                print(f"Warning: No data for {chapter_title}")
                continue

            chapter_dir = os.path.join(base_dir, chapter["dir"])
            os.makedirs(chapter_dir, exist_ok=True)

            chapter_data = results[matched_chapter_key]
            
            for section in chapter["sections"]:
                heading_clean = section["title"].replace("§", "").strip()
                match = next((item for item in chapter_data if heading_clean.endswith(item["heading"])), None)
                
                if not match:
                    print(f"Warning: No match for section '{section['title']}'")
                    continue

                section_data = {
                    "source": "san-mateo",
                    "title": section["title"],
                    "url": match["url"],
                    "html": match["html"]
                }

                filename = section["file"] + ".json"
                file_path = os.path.join(chapter_dir, filename)

                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(section_data, f, indent=2, ensure_ascii=False)

    @staticmethod
    def generate_csv(chapters, results, output_file="san_mateo_sections.csv"):
        rows = []
        
        for chapter_index, chapter in enumerate(chapters, 1):
            chapter_title = ContentProcessor.extract_chapter_name(chapter["title"])
            chapter_title_normalized = ContentProcessor.normalize(chapter_title)

            matched_chapter_key = next(
                (key for key in results if ContentProcessor.normalize(key).endswith(chapter_title_normalized)),
                None
            )

            if not matched_chapter_key:
                print(f"Warning: No data for chapter '{chapter_title}'")
                continue

            chapter_data = results[matched_chapter_key]
            
            for section_index, section in enumerate(chapter["sections"], 1):
                heading_clean = section["title"].replace("§", "").strip()
                section_url = section.get("url", "")

                match = next((item for item in chapter_data if heading_clean.endswith(item["heading"])), None
                if not match:
                    print(f"Warning: No match for section '{section['title']}' in CSV export")
                    continue

                paragraphs = match["text"].split("\n") if match["text"] else [""]
                for para in paragraphs:
                    if para.strip():
                        subsection_number = f"{chapter_index}.{section_index}"
                        zoneomics_url = f"https://zoneomics.com/code/san_mateo/chapter_{chapter_index}#{subsection_number}"

                        row = {
                            "chapter_no": chapter_index,
                            "heading_1": chapter_title,
                            "heading_2": match["heading"],
                            "subsection_number": f"sub-sec-{subsection_number}",
                            "source_url": match["url"],
                            "zoneomics_url": zoneomics_url,
                            "text": para.strip()
                        }
                        rows.append(row)

        with open(output_file, "w", encoding="utf-8", newline='') as csvfile:
            fieldnames = [
                "chapter_no", "heading_1", "heading_2", 
                "subsection_number", "source_url", "zoneomics_url", "text"
            ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)