from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import json
from urllib.parse import urlparse
from utils import *
# from utils import XPATHS
# import utils
# from utils import TableProcessor, ContentProcessor, XPATHS
# 
def scrape_san_mateo_code():
    # Initialize driver and get base URL
    driver = webdriver.Edge()
    url = "https://law.cityofsanmateo.org/us/ca/cities/san-mateo/code/27"
    parsed_url = urlparse(url)
    base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
    
    driver.get(url)
    time.sleep(3)

    # Find all chapter links
    chapter_links = driver.find_elements(By.XPATH, XPATHS["base"]["chapter_links"])
    results = {}

    for iter, chapter_link in enumerate(chapter_links, 1):
        chapter_link.click()
        time.sleep(3)

        chapter_title_1 = chapter_link.text.strip()
        chapter_number = chapter_title_1.split()[1]
        
        # Get chapter title
        chapter_title_element = driver.find_elements(
            By.XPATH, 
            XPATHS["base"]["chapter_title"].format(chapter_number=chapter_number)
        )
        chapter_title = chapter_title_element[0].text if chapter_title_element else chapter_title_1

        # Find all section headings
        h3_elements = driver.find_elements(
            By.XPATH, 
            XPATHS["base"]["section_heading"].format(chapter_number=chapter_number)
        )

        for i, h3 in enumerate(h3_elements, 1):
            id = h3.get_attribute("id")
            section_url = base_url + id
            file_number = f"{iter}.{i}"

            section = {
                "heading": h3.text.strip(),
                "id": id,
                "url": section_url,
                "file": file_number,
                "html": "",
                "text": ""
            }

            paragraphs_html = []
            paragraphs_text = []
            sibling = h3.find_element(By.XPATH, "following-sibling::*[1]")

            while sibling.tag_name not in ['h2', 'h3']:
                try:
                    tag = sibling.tag_name.lower()
                    cls = sibling.get_attribute("class")

                    if tag == 'p':
                        paragraphs_text.append(sibling.text.strip())
                        paragraphs_html.append(sibling.get_attribute('outerHTML'))
                    elif tag == 'div' and 'table_wrap' in cls:
                        table_element = sibling.find_element(By.TAG_NAME, 'table')
                        markdown_text = TableProcessor.table_to_markdown_with_chunks(table_element)
                        if markdown_text:
                            paragraphs_text.append(markdown_text)
                        paragraphs_html.append(sibling.get_attribute('outerHTML'))

                    sibling = sibling.find_element(By.XPATH, "following-sibling::*[1]")
                except:
                    break

            section["html"] = f"<div id='{file_number}'>{' '.join(paragraphs_html)}</div>"
            section["text"] = " ".join(paragraphs_text)

            if chapter_title not in results:
                results[chapter_title] = []
            results[chapter_title].append(section)

    # Process and save results
    transform_structure_content = ContentProcessor.transform_structure(results)
    
    with open("chapters.json", "w", encoding="utf-8") as f:
        json.dump(transform_structure_content, f, ensure_ascii=False, indent=4)

    ContentProcessor.save_chapters_wise_jsons(transform_structure_content, results)
    ContentProcessor.generate_csv(transform_structure_content, results)
    
    driver.quit()

if __name__ == "__main__":
    scrape_san_mateo_code()