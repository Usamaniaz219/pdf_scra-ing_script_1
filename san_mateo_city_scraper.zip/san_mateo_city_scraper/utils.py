import json
import re
import os
import csv
import time
import math
from urllib.parse import urlparse
from collections import Counter
from selenium.webdriver.common.by import By
from markdownify import markdownify as md

class ConfigLoader:
    """Handles loading of configuration files"""
    
    @staticmethod
    def load_xpaths():
        """Load XPaths from JSON configuration file"""
        try:
            config_dir = os.path.join(os.path.dirname(__file__), 'x_paths')
            xpaths_file = os.path.join(config_dir, 'xpath.json')
            
            if not os.path.exists(xpaths_file):
                raise FileNotFoundError(f"XPaths config file not found at: {xpaths_file}")
                
            with open(xpaths_file, 'r', encoding='utf-8') as f:
                return json.load(f)
                
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in xpaths.json: {str(e)}")
        except Exception as e:
            raise RuntimeError(f"Error loading XPaths config: {str(e)}")

# Load XPaths configuration
try:
    XPATHS = ConfigLoader.load_xpaths()
except Exception as e:
    print(f"Configuration error: {str(e)}")
    XPATHS = {}  # Fallback empty config


class TableProcessor:
    """Handles all table processing and conversion operations"""
    
    TABLE_START_MARKER = "\nTABLE STARTS HERE\n"
    TABLE_END_MARKER = "\nTABLE ENDS HERE\n"
    DUMMY_TOKEN = "UniQuE_TaBLe_TokEn_TO_bEE_RepLAcEd_LaTEr"
    
    @staticmethod
    def _has_min_alphanum(line: str, min_count: int = 3) -> bool:
        """Check if line contains minimum alphanumeric characters"""
        return sum(char.isalnum() for char in line) >= min_count

    @staticmethod
    def get_repeated_table_elements(table_elements: list) -> list:
        """Identify repeated/consecutive tables with similar content"""
        if not table_elements:
            return []
            
        repeated_tables = []
        i = 0
        while i < len(table_elements) - 1:
            current_text = table_elements[i].text.strip()
            next_text = table_elements[i + 1].text.strip()
            
            if current_text and current_text in next_text:
                repeated_tables.append(table_elements[i])
                i += 1
            i += 1
            
        return repeated_tables

    @staticmethod
    def get_shared_headings(repeated_tables: list) -> list:
        """Get common headings from repeated tables"""
        table_texts = [table.text for table in repeated_tables]
        return [item for item, count in Counter(table_texts).items() if count > 1] or None

    @staticmethod
    def remove_repeated_tables(table_elements: list) -> list:
        """Filter out duplicate/consecutive tables"""
        if not table_elements:
            return []
            
        filtered = []
        i = 0
        while i < len(table_elements) - 1:
            current = table_elements[i].text.strip()
            next_ = table_elements[i + 1].text.strip()
            
            if current and current in next_:
                i += 1
            else:
                filtered.append(table_elements[i])
            i += 1
            
        if i == len(table_elements) - 1:
            filtered.append(table_elements[-1])
            
        return filtered

    @staticmethod
    def replace_second_occurrence(text: str, substring: str, replacement: str = "") -> str:
        """Replace only the second occurrence of a substring"""
        first_idx = text.find(substring)
        if first_idx == -1:
            return text
            
        second_idx = text.find(substring, first_idx + len(substring))
        if second_idx == -1:
            return text
            
        return text[:second_idx] + replacement + text[second_idx + len(substring):]

    @staticmethod
    def remove_repeated_tables_text(page_text: str, duplicate_tables: list) -> str:
        """Clean page text by removing duplicate table content"""
        duplicate_headers = TableProcessor.get_shared_headings(duplicate_tables)
        duplicate_flag = False
        
        if duplicate_headers:
            for table in duplicate_tables:
                table_text = table.text
                if table_text not in duplicate_headers:
                    if table_text in page_text:
                        page_text = page_text.replace(table_text, "", 1)
                    else:
                        print("Warning: Table text not found for duplicate table")
                else:
                    if not duplicate_flag:
                        if table_text in page_text:
                            page_text = page_text.replace(table_text, "", 1)
                            duplicate_flag = True
                        else:
                            print("Warning: Table text not found for duplicate table")
            
            for table_text in duplicate_headers:
                page_text = TableProcessor.replace_second_occurrence(page_text, table_text)
        else:
            for table in duplicate_tables:
                table_text = table.text
                if table_text in page_text:
                    page_text = page_text.replace(table_text, "", 1)
                else:
                    print("Warning: Table text not found for duplicate table")
                    
        return page_text

    @staticmethod
    def get_large_tables_markdowns(table_elements: list) -> dict:
        """Identify tables that exceed size threshold"""
        return {
            idx: md(table.get_attribute("outerHTML"), heading_style="ATX", strip=["a"])
            for idx, table in enumerate(table_elements)
            if len(md(table.get_attribute("outerHTML"), heading_style="ATX", strip=["a"])) > 6000
        }

    @staticmethod
    def get_top_three_lines(table_markdown: str) -> str:
        """Extract the first three meaningful lines from table markdown"""
        lines = [
            line for line in table_markdown.split("\n")[:6] 
            if TableProcessor._has_min_alphanum(line)
        ][:3]
        return "\n".join(lines)

    @staticmethod
    def update_large_table_markdown(large_table_md: str) -> str:
        """Split large tables into manageable chunks"""
        if not large_table_md:
            return None
            
        full_md = ""
        lines = large_table_md.split("\n")
        total_lines = len(lines)
        top_lines = TableProcessor.get_top_three_lines(large_table_md)
        
        # Calculate chunk sizes
        chunk_size = 4000
        num_chunks = math.ceil(len(large_table_md) / chunk_size)
        lines_per_chunk = total_lines // num_chunks
        remainder = total_lines % num_chunks
        
        start = 0
        for i in range(num_chunks):
            end = start + lines_per_chunk + (1 if i < remainder else 0)
            chunk = " \n".join(lines[start:end])
            
            if i != 0:
                chunk = f"{top_lines}\n{chunk}"
                
            full_md += f"{TableProcessor.TABLE_START_MARKER}{chunk}{TableProcessor.TABLE_END_MARKER}"
            start = end
            
        if start != total_lines:
            print("Warning: Potential data loss during table splitting")
            return None
            
        return full_md

    @staticmethod
    def convert_table_text_to_markdown(table_elements: list) -> list:
        """Convert all tables to markdown format"""
        return [
            f"{TableProcessor.TABLE_START_MARKER}"
            f"{md(table.get_attribute('outerHTML'), heading_style='ATX', strip=['a'])}"
            f"{TableProcessor.TABLE_END_MARKER}"
            for table in table_elements
        ]

    @staticmethod
    def table_to_markdown_with_chunks(element) -> str:
        """Main pipeline for processing tables within an element"""
        valid_tables, all_tables = TableProcessor.detect_table_in_element(element)
        element_text = element.text
        
        if not valid_tables:
            return element_text
            
        # Process tables
        tables_md = TableProcessor.convert_table_text_to_markdown(valid_tables)
        
        # Handle large tables
        large_tables = TableProcessor.get_large_tables_markdowns(valid_tables)
        if large_tables:
            updated_md = TableProcessor.large_tables_pipeline(valid_tables)
            if updated_md:
                tables_md = updated_md
            else:
                print("Warning: Error processing large tables")
        
        # Handle duplicates
        duplicates = TableProcessor.get_repeated_table_elements(all_tables)
        if duplicates:
            element_text = TableProcessor.remove_repeated_tables_text(element_text, duplicates)
        
        # Replace table placeholders
        tables_text = TableProcessor.extract_table_text(valid_tables)
        dummy_text = TableProcessor.replace_table_text_with_dummy_text(element_text, tables_text)
        return TableProcessor.modify_tables_text(tables_md, dummy_text)


class ContentProcessor:
    """Handles content processing and output generation"""
    
    @staticmethod
    def transform_structure(data: dict) -> list:
        """Transform scraped data into organized structure"""
        output = []
        for idx, (title, sections) in enumerate(data.items(), 1):
            match = re.match(r"Chapter\s+([\d.]+)\s+(.*)", title)
            readable_title = match.group(2).title() if match else title
            
            article = {
                "title": f"Chapter {idx} {readable_title}",
                "dir": f"chapter_{idx}",
                "sections": [
                    {
                        "title": f"§ {sec['heading']}",
                        "file": f"{idx}.{i}",
                        "section": []
                    }
                    for i, sec in enumerate(sections, 1)
                ]
            }
            output.append(article)
        return output

    @staticmethod
    def extract_chapter_name(title: str) -> str:
        """Extract clean chapter name from title"""
        return re.sub(r'^Chapter\s+\d+\.?\s*', '', title, flags=re.IGNORECASE).strip()

    @staticmethod
    def normalize(text: str) -> str:
        """Normalize text for comparison"""
        return text.strip().rstrip('.').lower()

    @staticmethod
    def save_chapters_wise_jsons(chapters: list, results: dict, base_dir: str = "chapter_wise_jsons") -> None:
        """Save content as chapter-wise JSON files"""
        os.makedirs(base_dir, exist_ok=True)
        
        for idx, chapter in enumerate(chapters, 1):
            # Find matching chapter data
            chap_title = ContentProcessor.normalize(
                ContentProcessor.extract_chapter_name(chapter["title"]).upper()
            )
            chap_key = next(
                (k for k in results if ContentProcessor.normalize(k).endswith(chap_title)),
                None
            )
            
            if not chap_key:
                print(f"Warning: No data found for chapter {chapter['title']}")
                continue
                
            # Create chapter directory
            chap_dir = os.path.join(base_dir, chapter["dir"])
            os.makedirs(chap_dir, exist_ok=True)
            
            # Save each section
            for section in chapter["sections"]:
                heading = section["title"].replace("§", "").strip()
                section_data = next(
                    (item for item in results[chap_key] if heading.endswith(item["heading"])),
                    None
                )
                
                if not section_data:
                    print(f"Warning: No match for section '{section['title']}'")
                    continue
                    
                # Write JSON file
                with open(
                    os.path.join(chap_dir, f"{section['file']}.json"),
                    'w',
                    encoding='utf-8'
                ) as f:
                    json.dump({
                        "source": "san-mateo",
                        "title": section["title"],
                        "url": section_data["url"],
                        "html": section_data["html"]
                    }, f, indent=2, ensure_ascii=False)

    @staticmethod
    def generate_csv(chapters: list, results: dict, output_file: str = "san_mateo_sections.csv") -> None:
        """Generate CSV output from scraped data"""
        rows = []
        
        for chap_idx, chapter in enumerate(chapters, 1):
            # Find matching chapter data
            chap_title = ContentProcessor.extract_chapter_name(chapter["title"])
            norm_title = ContentProcessor.normalize(chap_title)
            chap_key = next(
                (k for k in results if ContentProcessor.normalize(k).endswith(norm_title)),
                None
            )
            
            if not chap_key:
                print(f"Warning: No data for chapter '{chap_title}'")
                continue
                
            # Process each section
            for sec_idx, section in enumerate(chapter["sections"], 1):
                heading = section["title"].replace("§", "").strip()
                section_data = next(
                    (item for item in results[chap_key] if heading.endswith(item["heading"])),
                    None
                )
                
                if not section_data:
                    print(f"Warning: No match for section '{section['title']}'")
                    continue
                    
                # Add CSV rows
                subsection = f"{chap_idx}.{sec_idx}"
                for para in (section_data["text"].split("\n") if section_data["text"] else [""]):
                    if para.strip():
                        rows.append({
                            "chapter_no": chap_idx,
                            "heading_1": chap_title,
                            "heading_2": section_data["heading"],
                            "subsection_number": f"sub-sec-{subsection}",
                            "source_url": section_data["url"],
                            "zoneomics_url": (
                                f"https://zoneomics.com/code/san_mateo/"
                                f"chapter_{chap_idx}#{subsection}"
                            ),
                            "text": para.strip()
                        })
        
        # Write CSV file
        with open(output_file, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=[
                "chapter_no", "heading_1", "heading_2",
                "subsection_number", "source_url", "zoneomics_url", "text"
            ])
            writer.writeheader()
            writer.writerows(rows)